import requests
import os

target_pid = input("enter pid> ")

while True:
    os.system("cls")
    source = input("enter script> ")
    if source == "cls":
        os.system("cls")
    else:
        try:
            requests.post(f"http://127.0.0.1:3110/execute?pid={target_pid}", data=source, headers={"Content-Type": "text/plain"})
        except Exception as e:
            print(f"error sendings request: {e}")