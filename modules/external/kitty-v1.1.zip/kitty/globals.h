#pragma once
#include <Windows.h>
#include <string>
#include "../../core/helpers.h"

namespace globals {
	DWORD pid = 0;
	bool attached = false;
}