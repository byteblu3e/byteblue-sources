﻿#include "kitty/kitty.h"
#include "core/instance.h"
#include "core/bytecode.h"
#include "core/helpers.h"
#include "server/server.h"
#include "execution/execution.h"
#include "debugger.h"
#include <iostream>
#include <conio.h>

int main(int argc, char* argv[]) {
    if (argc < 2) {
        printf("Usage: %s <PID>\n", argv[0]);
        return 1;
    }

    int pid = atoi(argv[1]);

    globals::pid = pid;

    helpers::clear_console(); // clear console output if you opening in cmd.exe

    SetConsoleTitleA("kitty (external executor for roblox)");

    if (kitty.attach(pid))
        log_debug() << "Attached successfully!";

    uintptr_t base = kitty.base_addr;

    if (base != NULL)
        log_debug() << "Found Roblox base address (0x" << std::hex << base << ")";

    std::string client_pid = std::to_string(kitty.pid);

    if (!server::start(3110, client_pid)) {
        log_err() << "Server failed to start on port 3110!";
        return 1;
    }

    // server listener for execution modules (to execute send POST request on http://127.0.0.1:3110/execute?pid=1111 and text/plain data)
    log_debug() << "Server started on http://127.0.0.1:3110 (PID: " << client_pid << ")";

    globals::attached = true;

    std::string client_folder_name = std::string(client_pid);

    uintptr_t last_datamodel = 0;
    bool first_print = true;

    while (true) {
        uintptr_t fake_datamodel = kitty.read<uintptr_t>(base + offsets::datamodel::pointer);
        uintptr_t real_datamodel = 0;

        if (fake_datamodel)
            real_datamodel = kitty.read<uintptr_t>(fake_datamodel + offsets::datamodel::real);

        if (real_datamodel != last_datamodel) {
            if (real_datamodel) {
                log_debug() << "Found DataModel (0x" << std::hex << real_datamodel << ") (" << rbx::instance(real_datamodel).name() << ")";

                if (rbx::instance(real_datamodel).name() == "Ugc") {
                    if (!rbx::instance(real_datamodel).find({ "CoreGui",client_folder_name })) {
                        auto hwnds = helpers::get_hwnd(kitty.pid);
                        HWND hwnd = nullptr;
                        if (!hwnds.empty()) hwnd = hwnds.front();

                        rbx::instance game = rbx::instance(real_datamodel);
                        if (game.address)
                            log_debug() << "Created game instance!";

                        rbx::script_context scriptcontext = rbx::script_context(game).get_script_context();
                        if (scriptcontext.address)
                            log_debug() << "Found ScriptContext (0x" << std::hex << scriptcontext.address << ")";

                        if (scriptcontext.set_bypass(true))
                            log_debug() << "Require bypassed in ScriptContext successfully!";

                        while (!kitty.read<bool>(game.address + offsets::datamodel::game_loaded))
                            Sleep(50);

                        rbx::instance players;
                        do {
                            players = game.find_first_child("Players");
                            Sleep(50);
                        } while (!players || players.get_children().empty());

                        std::string luau_init = helpers::init_parser();

                        bytecode::repStr(luau_init, "%client_pid%", client_pid); // don't change %client_pid% template if you not changed it in init.lua

                        std::vector<uint8_t> bytes = bytecode::prepare(luau_init);
                        if (bytes.empty()) {
                            log_err() << "Init bytecode prepare failed, it means what failed to prepare signed bytecode!";
                            continue;
                        }

                        Sleep(2000); // wait for full game loading to avoid a crash

                        rbx::script plm = game.find({
                            "CoreGui","RobloxGui","Modules","PlayerList", "PlayerListManager"
                            });
                        if (plm.address)
                            log_debug() << "Found PlayerListManager (0x" << std::hex << plm.address << ") (" << plm.class_name() << ")";

                        rbx::script jest = game.find({
                            "CorePackages","Packages","_Index","CollisionMatchers2D", "CollisionMatchers2D", "Jest"
                            });
                        if (jest.address)
                            log_debug() << "Found Jest (0x" << std::hex << jest.address << ") (" << jest.class_name() << ")";

                        kitty.write<int>(jest.address + offsets::script::modulescript::module_state, 0); // set modulestate to 0 to avoid crash

                        // injection
                        auto revert = jest.set_bytecode(bytes);
                        plm.spoof_to(jest);

                        HWND oldfg = GetForegroundWindow();
                        helpers::force_foreground(hwnd);
                        Sleep(50);
                        helpers::press_escape();
                        Sleep(50);
                        revert(); // call bytecode injection after pressing escape key
                        plm.spoof_to(plm);
                        helpers::press_escape();
                        if (oldfg && oldfg != hwnd) {
                            helpers::force_foreground(oldfg);
                        }
                        // end of injection

                        rbx::instance kitty_folder = game.find({ "CoreGui",client_folder_name });
                        while (!kitty_folder.address)
                            Sleep(50);
                        globals::attached = true;
                        log_info() << "Kitty folder has been created (" << kitty_folder.name() << ", " << kitty_folder.class_name() << ")";
                    }
                    else {
                        globals::attached = true;
                        log_info() << "Found existing Kitty folder, skipping injection...";
                    }
                }
                else if (rbx::instance(real_datamodel).name() == "LuaApp") {
                    rbx::instance game = rbx::instance(real_datamodel);
                    if (game.address)
                        log_debug() << "Created game instance!";
                    rbx::script_context(game.address).get_script_context().set_bypass(false);
                    if (!kitty.read<bool>(rbx::script_context(game.address).get_script_context().address + offsets::datamodel::require_bypass))
                        log_debug() << "Require bypass was set to false!";
                    globals::attached = false;
                }
            }
            else {
                if (!first_print)
                    log_err() << "DataModel lost (It mean you closed Roblox, and you need to re-attach)";
            }
            last_datamodel = real_datamodel;
            first_print = false;
        }

        Sleep(100);
    }

    if (kitty.detach())
        log_err() << "Detached :(";

    return 0;
}