#pragma once

#include "../execution/execution.h"
#include "../kitty/kitty.h"
#include "../core/instance.h"
#include "../core/bytecode.h"
#include "../globals.h"

#include <httplib/httplib.h>
#include <luacode.h>

#include <atomic>
#include <cstdint>
#include <cstring>
#include <functional>
#include <iostream>
#include <map>
#include <mutex>
#include <sstream>
#include <string>
#include <thread>
#include <unordered_map>
#include <vector>

namespace server {
    inline std::string url_decode(const std::string& s) {
        std::string out;
        out.reserve(s.size());
        for (size_t i = 0; i < s.size(); ++i) {
            if (s[i] == '%' && i + 2 < s.size()) {
                auto hex = [](char c) -> int {
                    if (c >= '0' && c <= '9') return c - '0';
                    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
                    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
                    return 0;
                    };
                out.push_back(static_cast<char>((hex(s[i + 1]) << 4) | hex(s[i + 2])));
                i += 2;
            }
            else if (s[i] == '+') {
                out.push_back(' ');
            }
            else {
                out.push_back(s[i]);
            }
        }
        return out;
    }

    inline std::map<std::string, std::string> parse_query(const std::string& q) {
        std::map<std::string, std::string> out;
        std::stringstream ss(q);
        std::string pair;
        while (std::getline(ss, pair, '&')) {
            auto eq = pair.find('=');
            if (eq == std::string::npos) {
                out[url_decode(pair)] = "";
            }
            else {
                out[url_decode(pair.substr(0, eq))] = url_decode(pair.substr(eq + 1));
            }
        }
        return out;
    }

    struct Context {
        std::string kitty_pid;
        uintptr_t base_addr = 0;
    };

    inline Context& ctx() {
        static Context c;
        return c;
    }

    inline void handle_ls(const httplib::Request& req, httplib::Response& res) {
        std::string query;
        auto qpos = req.target.find('?');
        if (qpos != std::string::npos) query = req.target.substr(qpos + 1);

        if (!globals::attached) {
            res.status = 400;
            res.set_content("attach first", "text/plain");
            return;
        }

        auto q = parse_query(query);
        std::string module_name = q.count("c") ? q["c"] : "";
        if (module_name.empty()) {
            res.status = 400;
            res.set_content("no c parameter", "text/plain");
            return;
        }

        if (last_script.empty()) {
            res.status = 204;
            res.set_content("", "text/plain");
            return;
        }

        std::string source = last_script;
        last_script.clear();

        std::string compiled = bytecode::compress(bytecode::__c(bytecode::sign(bytecode::compile("return function() " + source + " end"))));
        if (compiled.empty() || compiled[0] == '\0') {
            res.status = 500;
            res.set_content("compile failed", "text/plain");
            return;
        }
        std::vector<uint8_t> bytes(compiled.begin(), compiled.end());

        uintptr_t fake = kitty.read<uintptr_t>(kitty.base_addr + offsets::datamodel::pointer);
        uintptr_t dm = fake ? kitty.read<uintptr_t>(fake + offsets::datamodel::real) : 0;
        if (!dm) {
            res.status = 503;
            res.set_content("no datamodel", "text/plain");
            return;
        }

        rbx::instance game{ dm };
        rbx::instance container = game.find({ "CoreGui", ctx().kitty_pid});
        if (!container) {
            res.status = 404;
            res.set_content("no container", "text/plain");
            return;
        }

        rbx::instance mod;
        for (int i = 0; i < 20; ++i) {
            mod = container.find_first_child(module_name);
            if (mod) break;
            Sleep(100);
        }

        if (!mod) {
            res.status = 404;
            res.set_content("no module found with name: " + module_name, "text/plain");
            return;
        }

        rbx::script s = rbx::script::from(mod);
        s.unlock_module();
        s.set_bytecode(bytes);

        res.status = 200;
        res.set_content("ok", "text/plain");
    }

    inline void handle_execute(const httplib::Request& req, httplib::Response& res) {
        std::string query;
        auto qpos = req.target.find('?');
        if (qpos != std::string::npos) query = req.target.substr(qpos + 1);

        if (!globals::attached) {
            res.status = 400;
            res.set_content("attach first", "text/plain");
            return;
        }

        auto q = parse_query(query);
        std::string pid = q.count("pid") ? q["pid"] : "";

        if (pid.empty()) {
            res.status = 400;
            res.set_content("no pid parameter", "text/plain");
            return;
        }

        if (pid != ctx().kitty_pid) {
            res.status = 403;
            res.set_content("pid mismatch", "text/plain");
            return;
        }

        const std::string& src = req.body;
        if (src.empty()) {
            res.status = 400;
            res.set_content("empty script", "text/plain");
            return;
        }

        execute(src);

        res.status = 200;
        res.set_content("ok", "text/plain");
    }

    class serve {
    public:
        static serve& instance() {
            static serve s;
            return s;
        }

        bool start(uint16_t port, const std::string& kitty_pid) {
            ctx().kitty_pid = kitty_pid;

            m_svr.Post("/ls", handle_ls);
            m_svr.Post("/execute", handle_execute);

            m_svr.set_read_timeout(0.5, 0);
            m_svr.set_write_timeout(0.5, 0);
            m_svr.set_keep_alive_max_count(100);
            m_svr.set_keep_alive_timeout(0.5);

            m_running.store(true);
            m_thread = std::thread([this, port] {
                if (!m_svr.listen("127.0.0.1", port)) {
                    m_running.store(false);
                }
                });
            return true;
        }

        void stop() {
            if (!m_running.exchange(false)) return;
            m_svr.stop();
            if (m_thread.joinable()) m_thread.join();
        }

        uint16_t port() const { return m_port; }

    private:
        serve() = default;
        ~serve() { stop(); }
        serve(const serve&) = delete;
        serve& operator=(const serve&) = delete;

        httplib::Server m_svr;
        std::thread m_thread;
        std::atomic<bool> m_running{ false };
        uint16_t m_port = 0;
    };

    inline bool start(uint16_t port, const std::string& kitty_pid) {
        return serve::instance().start(port, kitty_pid);
    }

    inline void stop() {
        serve::instance().stop();
    }
}