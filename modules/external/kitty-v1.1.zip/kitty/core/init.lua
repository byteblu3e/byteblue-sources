-- made by @sleppy.lol._05074 (kittyy) and core modules execution by @quangaledingle (Flying_DUM12345)

local http_service = game:GetService("HttpService")
local core_gui = game:GetService("CoreGui")
local starter_gui = game:GetService("StarterGui")

local client_pid = "%client_pid%"
local server_url = "http://127.0.0.1:3110"

if core_gui:FindFirstChild(client_pid) then return end

local container = Instance.new("Folder", core_gui)
container.Name = client_pid

local loadstring_container = game

local kitty_env = getfenv(0)

-- core modules searcher (thanks to Flying_DUM12345 for realisation)
local function findModule(root)
    for _, child in ipairs(root:GetDescendants()) do
        if child:IsA("ModuleScript") then
            return child
        end
    end
    return nil
end

local function copyModule(name, parent)
    local packages = game:GetService("CorePackages"):FindFirstChild("Packages")
    local module = findModule(packages)
    if not module then warn("module script not found in packages") end
    local inst = module:Clone()
    inst.Name = name
    inst.Parent = parent or container
    return inst
end
-- end

-- server sender
local function sendData(path, body)
    local done, status = false, nil
    http_service:RequestInternal({
        Url = server_url .. path,
        Method = "POST",
        Body = body or "",
        Headers = { ["Content-Type"] = "text/plain" }
    }):Start(function(success, response)
        done = true
        if success then status = response.StatusCode end
    end)
    local t0 = tick()
    while not done and tick() - t0 < 5 do task.wait() end
    return status
end
-- end

-- unc functions
kitty_env.getgenv = function()
    return kitty_env
end

kitty_env.identifyexecutor = function()
    return "kitty","1.1"
end
-- end

-- listener
task.spawn(function()
    while task.wait() do
        local module_name = tostring(math.random(1, 1e9))
        local module = copyModule(module_name)

        local status = sendData("/ls?c=" .. module_name .. "&p=" .. client_pid, "")
            
        if status == 200 then
            local success, exec = pcall(require, module)
            if success and type(exec) == "function" then
                kitty_env.script = module
                pcall(setfenv, exec, kitty_env)
                task.spawn(exec)
                kitty_env.script = nil
            end
            module:Destroy()
        elseif status == 204 then
            module:Destroy()
        else
            task.wait()
        end
    end
end)
-- end

starter_gui:SetCore("SendNotification", {
    Title = "kitty external",
    Text = "magically attached to roblox!",
    Duration = 5,
})

return setmetatable({}, {
    __index = function()
        return function() end
    end
})