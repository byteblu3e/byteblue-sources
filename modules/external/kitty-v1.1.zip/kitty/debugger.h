#pragma once
#include <iostream>
#include <sstream>
#include <iomanip>
#include <chrono>
#include <ctime>
#include <windows.h>

#include "globals.h"

enum class log_type {
    debug,
    info,
    warn,
    err
};

class debugger {
public:
    debugger(log_type type, int line) : type_(type) {
        hConsole_ = GetStdHandle(STD_OUTPUT_HANDLE);
        GetConsoleScreenBufferInfo(hConsole_, &saved_info_);

        WORD brightWhite = FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_INTENSITY;
        SetConsoleTextAttribute(hConsole_, brightWhite);

        auto now = std::chrono::system_clock::now();
        std::time_t t = std::chrono::system_clock::to_time_t(now);
        std::tm tm{};
        localtime_s(&tm, &t);

        if (type == log_type::debug) {
            std::cout << "[Debug]";
        }
        else if (type == log_type::info) {
            std::cout << "[Info]";
        }
        else if (type == log_type::warn) {
            std::cout << "[Warning]";
        }
        else if (type == log_type::err) {
            SetConsoleTextAttribute(hConsole_, BACKGROUND_RED | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_INTENSITY);
            std::cout << "[Error]";
        }

        if (type_ == log_type::err) {
            WORD errorAttributes = BACKGROUND_RED | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_INTENSITY;
            SetConsoleTextAttribute(hConsole_, errorAttributes);

            std::cout << "[" << std::setfill('0') << std::setw(2) << tm.tm_hour << ':'
                << std::setfill('0') << std::setw(2) << tm.tm_min << ':'
                << std::setfill('0') << std::setw(2) << tm.tm_sec << ']'
                << "[" << GetCurrentProcessId() << "] ";
        }
        else {
            SetConsoleTextAttribute(hConsole_, brightWhite);

            std::cout << "[" << std::setfill('0') << std::setw(2) << tm.tm_hour << ':'
                << std::setfill('0') << std::setw(2) << tm.tm_min << ':'
                << std::setfill('0') << std::setw(2) << tm.tm_sec << ']'
                << "[" << GetCurrentProcessId() << "] ";
        }
    }

    ~debugger() {
        std::cout << stream_.str();
        SetConsoleTextAttribute(hConsole_, saved_info_.wAttributes);
        std::cout << std::endl;
    }

    template <typename T>
    debugger& operator<<(const T& msg) {
        stream_ << msg;
        return *this;
    }

    debugger& operator<<(std::ostream& (*manip)(std::ostream&)) {
        stream_ << manip;
        return *this;
    }
private:
    log_type type_;
    std::ostringstream stream_;
    HANDLE hConsole_;
    CONSOLE_SCREEN_BUFFER_INFO saved_info_;
};

#define log_debug() debugger(log_type::debug, __LINE__)
#define log_info()  debugger(log_type::info,  __LINE__)
#define log_warn()  debugger(log_type::warn,  __LINE__)
#define log_err()   debugger(log_type::err,   __LINE__)