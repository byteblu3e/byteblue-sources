#define WIN32_LEAN_AND_MEAN
#define NOMINMAX

#include <Windows.h>
#include <d3d11.h>
#include <dxgi.h>
#include <dwmapi.h>
#include <string>
#include <vector>
#include <iostream>
#include <cstdio>

#include "imgui.h"
#include "imgui_impl_win32.h"
#include "imgui_impl_dx11.h"

#include "memory.hpp"
#include "functions.hpp"
#include "esp.hpp"
#include "aim.hpp"
#include "assets.hpp"
#include "game.hpp"
#include "doors.hpp"
#include "trolls.hpp"
#include "notification.hpp"

#pragma comment(linker, "/SUBSYSTEM:WINDOWS")
#pragma comment(linker, "/ENTRY:mainCRTStartup")
#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")
#pragma comment(lib, "dwmapi.lib")

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND, UINT, WPARAM, LPARAM);

static HWND g_hwnd = nullptr;
static ID3D11Device* g_dev = nullptr;
static ID3D11DeviceContext* g_ctx = nullptr;
static IDXGISwapChain* g_sc = nullptr;
static ID3D11RenderTargetView* g_rtv = nullptr;
static bool g_open = false;
static HHOOK g_kb_hook = nullptr;
static HHOOK g_mouse_hook = nullptr;

static const char* kWindowTitle = "Simple External";
static const char* kVersionText = "version 1.2";

static HWND g_rbx_wnd_cache = nullptr;

static RECT s_menu_rect = { 0, 0, 0, 0 };
static bool s_menu_rect_valid = false;
static bool s_mouse_down_last = false;

static void set_clickthrough(bool on) {
    LONG_PTR ex = GetWindowLongPtrW(g_hwnd, GWL_EXSTYLE);
    bool cur = (ex & WS_EX_TRANSPARENT) != 0;
    if (on == cur) return;

    if (on) ex |= WS_EX_TRANSPARENT;
    else ex &= ~WS_EX_TRANSPARENT;
    SetWindowLongPtrW(g_hwnd, GWL_EXSTYLE, ex);
}

static void set_menu_open(bool on) {
    if (on && !g_open) {
        g_open = true;
        set_clickthrough(false);

        LONG_PTR ex = GetWindowLongPtrW(g_hwnd, GWL_EXSTYLE);
        ex &= ~WS_EX_NOACTIVATE;
        SetWindowLongPtrW(g_hwnd, GWL_EXSTYLE, ex);
        SetForegroundWindow(g_hwnd);
    }
    else if (!on && g_open) {
        g_open = false;
        set_clickthrough(true);

        LONG_PTR ex = GetWindowLongPtrW(g_hwnd, GWL_EXSTYLE);
        ex |= WS_EX_NOACTIVATE;
        SetWindowLongPtrW(g_hwnd, GWL_EXSTYLE, ex);

        HWND rbx = GetForegroundWindow();
        if (rbx) SetForegroundWindow(rbx);
    }
}

static bool roblox_foreground() {
    if (!rbx::g_pid) return false;
    HWND fg = GetForegroundWindow();
    if (!fg) return false;

    DWORD pid = 0;
    GetWindowThreadProcessId(fg, &pid);
    if (pid == rbx::g_pid) return true;

    HWND root = GetAncestor(fg, GA_ROOTOWNER);
    if (root) {
        DWORD rp = 0;
        GetWindowThreadProcessId(root, &rp);
        if (rp == rbx::g_pid) return true;
    }
    return false;
}

struct RobloxEnumCtx {
    DWORD pid;
    HWND* out;
};

static BOOL CALLBACK roblox_enum_cb(HWND h, LPARAM lp) {
    auto* c = (RobloxEnumCtx*)lp;
    DWORD pid = 0;
    GetWindowThreadProcessId(h, &pid);

    if (pid != c->pid) return TRUE;
    if (!IsWindowVisible(h)) return TRUE;
    if (GetWindow(h, GW_OWNER)) return TRUE;

    wchar_t t[64]{};
    GetWindowTextW(h, t, 64);
    if (wcslen(t) == 0) return TRUE;

    *c->out = h;
    return FALSE;
}

static HWND roblox_window() {
    if (!rbx::g_pid) return nullptr;
    if (g_rbx_wnd_cache && IsWindow(g_rbx_wnd_cache)) return g_rbx_wnd_cache;

    g_rbx_wnd_cache = nullptr;
    RobloxEnumCtx ctx{ rbx::g_pid, &g_rbx_wnd_cache };
    EnumWindows(roblox_enum_cb, (LPARAM)&ctx);
    return g_rbx_wnd_cache;
}

static bool point_in_rect(POINT p, const RECT& r) {
    return p.x >= r.left && p.x <= r.right && p.y >= r.top && p.y <= r.bottom;
}

static LRESULT CALLBACK kb_hook(int code, WPARAM w, LPARAM l) {
    if (code == HC_ACTION && w == WM_KEYDOWN) {
        auto* kb = (KBDLLHOOKSTRUCT*)l;
        if (kb->vkCode == VK_INSERT) {
            static DWORD last = 0;
            DWORD now = GetTickCount();
            if (now - last > 250) {
                last = now;
                set_menu_open(!g_open);
            }
            return 1;
        }
    }
    return CallNextHookEx(g_kb_hook, code, w, l);
}

static LRESULT CALLBACK mouse_hook(int code, WPARAM w, LPARAM l) {
    if (code == HC_ACTION && (w == WM_MOUSEWHEEL || w == WM_MOUSEHWHEEL)) {
        auto* ms = (MSLLHOOKSTRUCT*)l;
        POINT p = ms->pt;

        if (g_open && s_menu_rect_valid && point_in_rect(p, s_menu_rect)) {
            short delta = (short)HIWORD(ms->mouseData);
            float amount = ((float)delta / (float)WHEEL_DELTA) * 0.2f;

            if (w == WM_MOUSEWHEEL)
                ImGui::GetIO().AddMouseWheelEvent(0.0f, amount);
            else
                ImGui::GetIO().AddMouseWheelEvent(amount, 0.0f);

            return 1;
        }
    }
    return CallNextHookEx(g_mouse_hook, code, w, l);
}

static LRESULT CALLBACK wndproc(HWND h, UINT m, WPARAM w, LPARAM l) {
    if (ImGui_ImplWin32_WndProcHandler(h, m, w, l)) return true;

    if (m == WM_SIZE && g_dev && w != SIZE_MINIMIZED && g_sc) {
        if (g_rtv) {
            g_rtv->Release();
            g_rtv = nullptr;
        }

        g_sc->ResizeBuffers(0, LOWORD(l), HIWORD(l), DXGI_FORMAT_UNKNOWN, 0);

        ID3D11Texture2D* bb = nullptr;
        if (SUCCEEDED(g_sc->GetBuffer(0, IID_PPV_ARGS(&bb))) && bb) {
            g_dev->CreateRenderTargetView(bb, nullptr, &g_rtv);
            bb->Release();
        }
        return 0;
    }

    if (m == WM_SYSCOMMAND && (w & 0xfff0) == SC_KEYMENU) return 0;
    if (m == WM_DESTROY) {
        PostQuitMessage(0);
        return 0;
    }

    return DefWindowProcW(h, m, w, l);
}

static bool init_d3d(HWND h) {
    DXGI_SWAP_CHAIN_DESC sd{};
    sd.BufferCount = 2;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferDesc.RefreshRate = { 60, 1 };
    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow = h;
    sd.SampleDesc.Count = 1;
    sd.Windowed = TRUE;
    sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;

    D3D_FEATURE_LEVEL lv[] = { D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_0 };
    D3D_FEATURE_LEVEL got{};

    if (FAILED(D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0,
        lv, 2, D3D11_SDK_VERSION, &sd, &g_sc, &g_dev, &got, &g_ctx))) {
        return false;
    }

    ID3D11Texture2D* bb = nullptr;
    g_sc->GetBuffer(0, IID_PPV_ARGS(&bb));
    if (!bb) return false;

    g_dev->CreateRenderTargetView(bb, nullptr, &g_rtv);
    bb->Release();
    return true;
}

static void setup_fonts() {
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;
    ImFontConfig defCfg;
    defCfg.SizePixels = 15.0f;
    io.Fonts->AddFontDefault(&defCfg);
}

static void draw_player_card() {
    uint64_t uid = features::LocalUserId();
    std::string player = features::LocalName();
    std::string place = features::PlaceName();
    uint64_t place_id = features::PlaceId();
    std::string server = features::ServerId();

    if (player.empty()) player = "not attached";
    if (place.empty()) place = "main menu";

    if (uid) assets::RequestAvatar(uid);
    if (place_id) assets::RequestGameIcon(place_id);

    ImVec2 p = ImGui::GetCursorScreenPos();
    ImDrawList* dl = ImGui::GetWindowDrawList();

    const float icon = 44.0f;
    ImU32 bg = IM_COL32(30, 36, 48, 255);
    ImU32 brd = IM_COL32(70, 90, 130, 255);

    dl->AddRectFilled(p, ImVec2(p.x + icon, p.y + icon), bg, 5.0f);

    assets::Image av;
    bool has_av = uid && assets::GetAvatar(uid, av);
    if (has_av && av.srv) {
        dl->AddImageRounded((ImTextureID)(intptr_t)av.srv,
            p, ImVec2(p.x + icon, p.y + icon),
            ImVec2(0, 0), ImVec2(1, 1), IM_COL32_WHITE, 5.0f);
    }
    else {
        ImU32 fg = IM_COL32(140, 160, 200, 255);
        float cx = p.x + icon * 0.5f;
        dl->AddCircleFilled(ImVec2(cx, p.y + icon * 0.36f), icon * 0.16f, fg, 16);
        dl->AddRectFilled(ImVec2(cx - icon * 0.26f, p.y + icon * 0.58f),
            ImVec2(cx + icon * 0.26f, p.y + icon * 0.82f), fg, icon * 0.18f);
    }
    dl->AddRect(p, ImVec2(p.x + icon, p.y + icon), brd, 5.0f);

    ImGui::Dummy(ImVec2(icon, icon));
    ImGui::SameLine(0, 10);

    ImGui::BeginGroup();
    ImGui::Spacing();
    ImGui::TextUnformatted(player.c_str());
    ImGui::TextDisabled("%s", place.c_str());
    ImGui::EndGroup();

    ImGui::Spacing();
    ImGui::Separator();
    ImGui::Spacing();

    assets::Image gi;
    bool has_gi = place_id && assets::GetGameIcon(place_id, gi);
    ImVec2 gi_pos = ImGui::GetCursorScreenPos();
    const float gsz = 40.0f;

    if (has_gi && gi.srv) {
        dl->AddImageRounded((ImTextureID)(intptr_t)gi.srv, gi_pos, ImVec2(gi_pos.x + gsz, gi_pos.y + gsz), ImVec2(0, 0), ImVec2(1, 1), IM_COL32_WHITE, 5.0f);
    }
    else {
        dl->AddRectFilled(gi_pos, ImVec2(gi_pos.x + gsz, gi_pos.y + gsz), bg, 5.0f);
    }
    dl->AddRect(gi_pos, ImVec2(gi_pos.x + gsz, gi_pos.y + gsz), brd, 5.0f);

    ImGui::Dummy(ImVec2(gsz, gsz));
    ImGui::SameLine(0, 10);

    std::string short_server = server;
    if (short_server.size() > 20) short_server = short_server.substr(0, 20) + "...";

    ImGui::BeginGroup();
    ImGui::TextDisabled("user id"); ImGui::SameLine(85); ImGui::TextDisabled("%llu", (unsigned long long)uid);
    ImGui::TextDisabled("place id"); ImGui::SameLine(85); ImGui::TextDisabled("%llu", (unsigned long long)place_id);
    ImGui::TextDisabled("server"); ImGui::SameLine(85);
    if (short_server.empty()) ImGui::TextDisabled("--");
    else ImGui::TextDisabled("%s", short_server.c_str());
    ImGui::EndGroup();
}

static void draw_menu() {
    ImGui::SetNextWindowSize(ImVec2(468, 500), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowPos(ImVec2(80, 80), ImGuiCond_FirstUseEver);

    ImGuiWindowFlags flags =
        ImGuiWindowFlags_NoCollapse |
        ImGuiWindowFlags_NoResize |
        ImGuiWindowFlags_NoSavedSettings;

    ImGui::Begin(kWindowTitle, &g_open, flags);

    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(8.0f, 6.0f));
    ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(12.0f, 3.0f));

    if (ImGui::BeginTabBar("##tabs", ImGuiTabBarFlags_None)) {
        if (ImGui::BeginTabItem("Home")) {
            ImGui::Spacing();
            draw_player_card();
            ImGui::Spacing();
            ImGui::Separator();
            ImGui::Spacing();

            ImGui::TextUnformatted("Walkspeed");
            ImGui::SetNextItemWidth(-1);
            ImGui::SliderFloat("##ws", &features::walkspeed, 16.f, 500.f, "%.0f");

            ImGui::TextUnformatted("Jump Power");
            ImGui::SetNextItemWidth(-1);
            ImGui::SliderFloat("##jp", &features::jumppower, 0.f, 500.f, "%.0f");

            ImGui::TextUnformatted("Hip Height");
            ImGui::SetNextItemWidth(-1);
            ImGui::SliderFloat("##hh", &features::hipheight, 0.f, 20.f, "%.1f");

            ImGui::Spacing();
            ImGui::Separator();
            ImGui::TextUnformatted("Movement");

            ImGui::Checkbox("Fly", &features::fly_enabled);
            if (features::fly_enabled) {
                ImGui::TextUnformatted("Fly Speed");
                ImGui::SetNextItemWidth(-1);
                ImGui::SliderFloat("##flyspd", &features::fly_speed, 10.f, 400.f, "%.0f");
            }
            ImGui::TextDisabled("W/A/S/D + Space/Ctrl");

            ImGui::Checkbox("Noclip", &features::noclip_enabled);
            ImGui::Checkbox("Infinite Jump", &features::infinite_jump);

            ImGui::Spacing();
            ImGui::Separator();
            ImGui::TextUnformatted("World");

            ImGui::TextUnformatted("Camera FOV (0 = off)");
            ImGui::SetNextItemWidth(-1);
            ImGui::SliderFloat("##fov", &features::camera_fov, 0.f, 120.f, "%.0f");

            ImGui::Checkbox("Custom Gravity", &features::gravity_enabled);
            if (features::gravity_enabled) {
                ImGui::TextUnformatted("Gravity");
                ImGui::SetNextItemWidth(-1);
                ImGui::SliderFloat("##grav", &features::gravity_value, 0.f, 500.f, "%.1f");
            }

            ImGui::Spacing();
            ImGui::Separator();
            ImGui::Spacing();
            ImGui::TextDisabled("%s", kVersionText);

            ImGui::EndTabItem();
        }

        if (ImGui::BeginTabItem("ESP")) {
            esp::DrawTab();
            ImGui::EndTabItem();
        }

        if (ImGui::BeginTabItem("Aim")) {
            aim::DrawTab();
            ImGui::EndTabItem();
        }

        if (doors::IsDoorsGame()) {
            if (ImGui::BeginTabItem("Doors")) {
                doors::DrawTab();
                ImGui::EndTabItem();
            }
        }

        if (ImGui::BeginTabItem("Troll")) {
            trolls::DrawTab();
            ImGui::EndTabItem();
        }

        if (ImGui::BeginTabItem("Game")) {
            game::DrawTab();
            ImGui::EndTabItem();
        }

        ImGui::EndTabBar();
    }

    ImGui::PopStyleVar(2);

    ImVec2 wp = ImGui::GetWindowPos();
    ImVec2 ws = ImGui::GetWindowSize();

    s_menu_rect.left = (LONG)wp.x;
    s_menu_rect.top = (LONG)wp.y;
    s_menu_rect.right = (LONG)(wp.x + ws.x);
    s_menu_rect.bottom = (LONG)(wp.y + ws.y);
    s_menu_rect_valid = true;

    ImGui::End();
}

static void tick_menu_focus() {
    POINT p;
    GetCursorPos(&p);
    bool now_down = (GetAsyncKeyState(VK_LBUTTON) & 0x8000) != 0;
    bool over = g_open && s_menu_rect_valid && point_in_rect(p, s_menu_rect);

    if (now_down && !s_mouse_down_last) {
        if (over) set_clickthrough(false);
    }
    else if (!now_down) {
        set_clickthrough(!over);
    }

    s_mouse_down_last = now_down;
}

int main() {
    AllocConsole();
    FILE* fDummy;
    freopen_s(&fDummy, "CONOUT$", "w", stdout);
    freopen_s(&fDummy, "CONOUT$", "w", stderr);
    freopen_s(&fDummy, "CONIN$", "r", stdin);
    SetConsoleTitleW(L"Simple External");

    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_INTENSITY);
    std::cout << "[+] Simple External Loaded\n";
    SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);

    CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);

    if (!rbx::Attach()) {
        SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_INTENSITY);
        std::cout << "[-] Roblox process not found. Please open Roblox.\n";
        std::cout << "Press Enter to exit...\n";
        SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);

        std::cin.get();
        FreeConsole();
        CoUninitialize();
        return 0;
    }

    SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_INTENSITY);
    std::cout << "[+] Attached to Roblox successfully.\n";
    SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);

    Sleep(800);
    ShowWindow(GetConsoleWindow(), SW_HIDE);

    WNDCLASSEXW wc{};
    wc.cbSize = sizeof(wc);
    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = wndproc;
    wc.hInstance = GetModuleHandleW(nullptr);
    wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
    wc.lpszClassName = L"SimpleExternalWnd";
    RegisterClassExW(&wc);

    int sw = GetSystemMetrics(SM_CXSCREEN);
    int sh = GetSystemMetrics(SM_CYSCREEN);

    g_hwnd = CreateWindowExW(
        WS_EX_TOPMOST | WS_EX_TRANSPARENT | WS_EX_LAYERED |
        WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE,
        wc.lpszClassName, L"Simple External", WS_POPUP,
        0, 0, sw, sh, nullptr, nullptr, wc.hInstance, nullptr);
    if (!g_hwnd) return 1;

    SetLayeredWindowAttributes(g_hwnd, 0, 255, LWA_ALPHA);
    MARGINS mg{ -1, -1, -1, -1 };
    DwmExtendFrameIntoClientArea(g_hwnd, &mg);
    ShowWindow(g_hwnd, SW_SHOW);

    if (!init_d3d(g_hwnd)) return 1;

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    setup_fonts();
    ImGui::StyleColorsDark();

    ImGui::GetStyle().ScrollbarSize = 6.0f;

    ImGui_ImplWin32_Init(g_hwnd);
    ImGui_ImplDX11_Init(g_dev, g_ctx);

    g_open = false;
    set_clickthrough(true);

    g_kb_hook = SetWindowsHookExW(WH_KEYBOARD_LL, kb_hook, GetModuleHandleW(nullptr), 0);
    g_mouse_hook = SetWindowsHookExW(WH_MOUSE_LL, mouse_hook, GetModuleHandleW(nullptr), 0);

    features::Start();
    aim::Init();
    game::Init();
    doors::Init();
    trolls::Init();

    MSG msg{};
    while (true) {
        while (PeekMessageW(&msg, nullptr, 0, 0, PM_REMOVE)) {
            TranslateMessage(&msg);
            DispatchMessageW(&msg);
            if (msg.message == WM_QUIT) goto done;
        }

        if (!rbx::alive()) goto done;

        features::Tick();
        tick_menu_focus();
        assets::Drain(g_dev);
        doors::Tick();
        trolls::Tick();

        bool rbx_fg = roblox_foreground();
        bool want_overlay = rbx_fg || g_open;

        static bool s_overlay_shown = true;
        if (want_overlay != s_overlay_shown) {
            ShowWindow(g_hwnd, want_overlay ? SW_SHOWNOACTIVATE : SW_HIDE);
            s_overlay_shown = want_overlay;
        }

        ImGui_ImplDX11_NewFrame();
        ImGui_ImplWin32_NewFrame();
        ImGui::NewFrame();

        if (rbx_fg) {
            esp::Draw(ImGui::GetBackgroundDrawList());
            aim::DrawOverlay();
            doors::DrawVisuals(ImGui::GetBackgroundDrawList());
        }

        if (g_open)
            draw_menu();

        notification::Draw();

        ImGui::Render();
        const float clear[4] = { 0, 0, 0, 0 };
        g_ctx->OMSetRenderTargets(1, &g_rtv, nullptr);
        g_ctx->ClearRenderTargetView(g_rtv, clear);
        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
        g_sc->Present(0, 0);
    }

done:
    if (g_kb_hook) UnhookWindowsHookEx(g_kb_hook);
    if (g_mouse_hook) UnhookWindowsHookEx(g_mouse_hook);

    aim::Shutdown();
    features::Stop();
    game::Shutdown();
    doors::Shutdown();
    trolls::Shutdown();
    assets::Shutdown();

    ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();

    if (g_rtv) g_rtv->Release();
    if (g_sc) g_sc->Release();
    if (g_ctx) g_ctx->Release();
    if (g_dev) g_dev->Release();
    if (g_hwnd) DestroyWindow(g_hwnd);

    UnregisterClassW(wc.lpszClassName, wc.hInstance);

    CoUninitialize();
    FreeConsole();
    return 0;
}