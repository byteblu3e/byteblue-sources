#include "doors.hpp"
#include "notification.hpp"
#include "memory.hpp"
#include "offsets.hpp"

#include <Windows.h>
#include <thread>
#include <mutex>
#include <vector>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <cmath>
#include <algorithm>

namespace doors {

    struct V3 { float x, y, z; };
    struct V2 { float x, y; };
    struct M3 { float m[9]; };

    enum Cat {
        CAT_ENTITY = 0, CAT_OBJECTIVE, CAT_DOOR, CAT_HIDING,
        CAT_CHEST, CAT_ITEM, CAT_CURRENCY, CAT_STAIRWELL, CAT_ARCHIVES
    };

    struct CachedObj {
        uintptr_t addr = 0;
        int cat = CAT_ITEM;
        std::string display;
        uintptr_t prim = 0;
        V3 pos{};
        V3 size{ 1,1,1 };
    };

    // Settings
    static bool s_enabled = false;
    static bool s_force_enable = false;
    static float s_max_dist = 150.0f;

    static bool s_esp_entities = true;
    static bool s_esp_objectives = true;
    static bool s_esp_doors = true;
    static bool s_esp_hiding = true;
    static bool s_esp_chests = true;
    static bool s_esp_items = true;
    static bool s_esp_currency = true;
    static bool s_esp_stairwell = true;
    static bool s_esp_archives = true;

    static bool s_show_tracers = false;
    static int s_tracer_origin = 0;
    static float s_tracer_thickness = 1.0f;
    static bool s_show_names = true;
    static bool s_show_dist = true;

    // Farm
    static bool s_tp_next_door = false;
    static float s_farm_speed = 0.15f;
    static bool s_draw_path = false;

    // Colors
    static float c_entity[4] = { 1.00f, 0.20f, 0.20f, 1.0f };
    static float c_objective[4] = { 0.20f, 1.00f, 0.20f, 1.0f };
    static float c_door[4] = { 0.00f, 0.78f, 1.00f, 1.0f };
    static float c_hiding[4] = { 1.00f, 0.66f, 0.00f, 1.0f };
    static float c_chest[4] = { 1.00f, 1.00f, 0.00f, 1.0f };
    static float c_item[4] = { 0.66f, 0.00f, 1.00f, 1.0f };
    static float c_currency[4] = { 1.00f, 0.80f, 0.00f, 1.0f };
    static float c_stairwell[4] = { 1.00f, 0.40f, 0.80f, 1.0f };
    static float c_archives[4] = { 0.40f, 0.60f, 1.00f, 1.0f };

    static std::vector<CachedObj> g_objects;
    static std::mutex g_mutex;
    static std::unordered_set<std::string> g_notified;
    static std::unordered_set<std::string> g_pending_notifs;
    static std::unordered_map<uintptr_t, float> g_alpha_cache;
    static bool g_running = true;

    static const std::unordered_map<std::string, std::pair<std::string, std::string>>& EntityTable() {
        static const std::unordered_map<std::string, std::pair<std::string, std::string>> t = {
            { "RushMoving",        { "Rush", "Find a hiding spot." } },
            { "AmbushMoving",      { "Ambush", "Find a hiding spot." } },
            { "Eyes",              { "Eyes", "Avoid looking at it." } },
            { "Lookman",           { "Lookman", "Avoid looking at its eyes." } },
            { "A60",               { "A-60", "Find a hiding spot." } },
            { "A120",              { "A-120", "Find a hiding spot." } },
            { "FigureRig",         { "Figure", "Avoid it, hide." } },
            { "FigureRagdoll",     { "Figure", "Avoid it, hide." } },
            { "Figure",            { "Figure", "Avoid it, hide." } },
            { "Seek",              { "Seek", "Run!" } },
            { "Halt",              { "Halt", "Look away." } },
            { "Screech",           { "Screech", "Look at it." } },
        };
        return t;
    }

    static const std::unordered_map<std::string, const char*>& HidingTable() {
        static const std::unordered_map<std::string, const char*> t = {
            { "Wardrobe","Closet" },{ "Backdoor_Wardrobe","Closet" },
            { "Toolshed","Closet" },{ "RetroWardrobe","Closet" },
            { "Wardrobe-FOOLS26","Closet" },{ "Locker_Large","Locker" },
            { "Rooms_Locker","Locker" },{ "Rooms_Locker_Fridge","Locker" },
            { "Bed","Bed" },{ "Double_Bed","Double Bed" },
            { "CircularVent","Vent" },{ "Dumpster","Dumpster" },
            { "SquareGrate","Grate" },
        };
        return t;
    }

    static const std::unordered_map<std::string, const char*>& ChestTable() {
        static const std::unordered_map<std::string, const char*> t = {
            { "ChestBox","Chest" }, { "ChestBoxLocked","Locked Chest" },
            { "Toolbox","Toolbox" }, { "Toolbox_Locked","Locked Toolbox" },
            { "Chest_Vine","Vine Chest" }, { "Toolshed_Small","Toolshed" },
            { "Locker_Small_Locked","Locked Item Locker" }, { "MouseHole","Mouse" },
        };
        return t;
    }

    static const std::unordered_map<std::string, const char*>& ItemTable() {
        static const std::unordered_map<std::string, const char*> t = {
            { "Lighter","Lighter" },{ "Flashlight","Flashlight" },{ "Lockpick","Lockpicks" },
            { "Vitamins","Vitamins" },{ "Bandage","Bandage" },{ "StarVial","Starlight Vial" },
            { "StarBottle","Starlight Bottle" },{ "StarJug","Starlight Barrel" },
            { "Shakelight","Gummy Flashlight" },{ "Straplight","Straplight" },
            { "Bulklight","Spotlight" },{ "Battery","Battery" },{ "Candle","Candle" },
            { "Crucifix","Crucifix" },{ "CrucifixWall","Crucifix" },{ "Glowsticks","Glowstick" },
            { "SkeletonKey","Skeleton Key" },{ "Candy","Candy" },{ "ShieldMini","Mini Shield Potion" },
            { "ShieldBig","Big Shield Potion" },{ "BandagePack","Bandage Pack" },
            { "BatteryPack","Battery Pack" },{ "RiftCandle","Moonlight Candle" },
            { "LaserPointer","Laser Pointer" },{ "HolyGrenade","Holy Hand Grenade" },
            { "Shears","Shears" },{ "Smoothie","Smoothie" },{ "Cheese","Cheese" },
            { "Bread","Bread" },{ "AlarmClock","Alarm Clock" },{ "RiftSmoothie","Moonlight Smoothie" },
            { "GweenSoda","Gween Soda" },{ "GlitchCube","Glitch Fragment" },{ "Scanner","Tablet" },
            { "Bomb","Bomb" },{ "Knockbomb","Knockbomb" },{ "Nanner","Nanner" },
            { "BigBomb","Big Bomb" },{ "SnakeBox","Hiding Box" },{ "GoldGun","Golden Gun" },
            { "StopSign","Stop Sign" },{ "TipJar","Tip Jar" },{ "Lantern","Lantern" },
            { "IronKey","Iron Key" },{ "LotusPetal","Lotus Petal" },{ "Compass","Compass" },
            { "LotusPetalPickup","Lotus Petal" },{ "LanternLitItem","Lantern" },
            { "KeyIron","Iron Key" },{ "IronKeyForCrypt","Iron Key" },
            { "LotusHolder","Lotus Petal" },{ "Multitool","Multitool" },{ "RiftJar","Rift Jar" },
            { "AloeVera","Aloe Vera" },{ "Donut","Donut" },{ "Lotus","Lotus" },
            { "BoxingGloves","Boxing Gloves" },{ "Green_Herb","Green Herb" },
        };
        return t;
    }

    static const std::unordered_map<std::string, const char*>& ObjectiveTable() {
        static const std::unordered_map<std::string, const char*> t = {
            { "KeyObtain","Door Key" },{ "ElectricalKeyObtain","Electrical Key" },
            { "MinesGenerator","Generator" },{ "FuseObtain","Generator Fuse" },
            { "LiveHintBook","Hint Book" },{ "LiveBreakerPolePickup","Fuse Breaker" },
            { "LibraryHintPaper","Hint Paper" },{ "PickupItem","Hint Paper" },
            { "CringlePresent","Present" },{ "LeverForGate","Gate Lever" },
            { "MinesGateButton","Gate Button" },{ "GardenGateButton","Gate Button" },
            { "MinesAnchor","Anchor" },{ "WaterPump","Water Pump" },
            { "VineGuillotine","Vine Lever" },{ "TimerLever","Time Lever" },
            { "StairwellScrapper","Scrapper" },{ "ArchivesPackageDeposit","Box Deposit" },
            { "Cellar","Cellar" },{ "Mirror","Mirror" },{ "StairwellLockpickDoor","Garage Door" },
        };
        return t;
    }

    static const std::unordered_map<std::string, const char*>& StairwellTable() {
        static const std::unordered_map<std::string, const char*> t = {
            { "ShoppingCart","Shopping Cart" }, { "StairwellFireAlarm","Fire Alarm" },
            { "MeldWall","Meld Wall" }, { "Boleahghth29tdgfhy2thuy2htuu259uhh3u","Meld Wall" },
            { "StairwellCrusherContainer1","Crusher" }, { "Grinder1","Grinder" }
        };
        return t;
    }

    static const std::unordered_map<std::string, const char*>& ArchivesTable() {
        static const std::unordered_map<std::string, const char*> t = {
            { "ArchivesFihTank","Fih Tank" }, { "ArchivesClock","Clock" },
            { "ArchivesStorageBox","Storage Box" }
        };
        return t;
    }

    bool IsDoorsGame() {
        if (!rbx::g_base) return false;
        uintptr_t fdm = rbx::Read<uintptr_t>(rbx::g_base + Offsets::FakeDataModel::Pointer);
        if (!fdm) return false;
        uintptr_t dm = rbx::Read<uintptr_t>(fdm + Offsets::FakeDataModel::RealDataModel);
        if (!dm) return false;
        uint64_t place_id = rbx::Read<uint64_t>(dm + Offsets::DataModel::PlaceId);
        return place_id == 6839171747ULL || place_id == 18352758168ULL || place_id == 16945970239ULL;
    }

    static uintptr_t GetLocalHRP() {
        uintptr_t fdm = rbx::Read<uintptr_t>(rbx::g_base + Offsets::FakeDataModel::Pointer);
        if (!fdm) return 0;
        uintptr_t dm = rbx::Read<uintptr_t>(fdm + Offsets::FakeDataModel::RealDataModel);
        if (!dm) return 0;

        uintptr_t players = 0;
        uintptr_t vec = rbx::Read<uintptr_t>(dm + Offsets::Instance::ChildrenStart);
        if (vec) {
            uintptr_t b = rbx::Read<uintptr_t>(vec);
            if (b) {
                for (int i = 0; i < 10; i++) {
                    uintptr_t c = rbx::Read<uintptr_t>(b + i * 16);
                    if (c && rbx::ReadStr(rbx::Read<uintptr_t>(c + Offsets::Instance::NameContainer) + Offsets::Instance::Name) == "Players") {
                        players = c;
                        break;
                    }
                }
            }
        }

        if (!players) return 0;
        uintptr_t lp = rbx::Read<uintptr_t>(players + Offsets::Player::LocalPlayer);
        if (!lp) return 0;
        uintptr_t chr = rbx::Read<uintptr_t>(lp + Offsets::Player::ModelInstance);
        if (!chr) return 0;

        uintptr_t cvec = rbx::Read<uintptr_t>(chr + Offsets::Instance::ChildrenStart);
        if (cvec) {
            uintptr_t cb = rbx::Read<uintptr_t>(cvec);
            if (cb) {
                for (int i = 0; i < 20; i++) {
                    uintptr_t c = rbx::Read<uintptr_t>(cb + i * 16);
                    if (c && rbx::ReadStr(rbx::Read<uintptr_t>(c + Offsets::Instance::NameContainer) + Offsets::Instance::Name) == "HumanoidRootPart") {
                        return rbx::Read<uintptr_t>(c + Offsets::BasePart::Primitive);
                    }
                }
            }
        }
        return 0;
    }

    static std::string read_name(uintptr_t inst) {
        uintptr_t nc = rbx::Read<uintptr_t>(inst + Offsets::Instance::NameContainer);
        if (!nc) return "";
        return rbx::ReadStr(nc + Offsets::Instance::Name);
    }

    static std::string read_class(uintptr_t inst) {
        uintptr_t cd = rbx::Read<uintptr_t>(inst + Offsets::Instance::ClassDescriptor);
        if (!cd) return "";
        std::string s = rbx::ReadStr(cd + Offsets::Instance::ClassName);
        if (!s.empty()) return s;

        uintptr_t ptr = rbx::Read<uintptr_t>(cd + Offsets::Instance::ClassName);
        if (ptr) {
            char buf[64] = { 0 };
            SIZE_T bytes = 0;
            ReadProcessMemory(rbx::g_handle, (LPCVOID)ptr, buf, sizeof(buf) - 1, &bytes);
            return std::string(buf);
        }
        return "";
    }

    static bool ClassIsBasePart(const std::string& cls) {
        return cls == "Part" || cls == "MeshPart" || cls == "UnionOperation" ||
            cls == "WedgePart" || cls == "CornerWedgePart" || cls == "TrussPart" ||
            cls == "SpawnLocation" || cls == "Seat" || cls == "VehicleSeat";
    }

    static bool has_child(uintptr_t obj, const char* child_name) {
        uintptr_t vec = rbx::Read<uintptr_t>(obj + Offsets::Instance::ChildrenStart);
        if (!vec) return false;

        uintptr_t b = rbx::Read<uintptr_t>(vec);
        uintptr_t e = rbx::Read<uintptr_t>(vec + 8);
        if (!b || !e || e <= b) return false;

        size_t n = (e - b) / 16;
        for (size_t i = 0; i < n && i < 100; i++) {
            uintptr_t c = rbx::Read<uintptr_t>(b + i * 16);
            if (c && read_name(c) == child_name) return true;
        }
        return false;
    }

    static uintptr_t PrimOf(uintptr_t o) {
        if (!o) return 0;
        std::string cls = read_class(o);
        if (ClassIsBasePart(cls)) {
            return rbx::Read<uintptr_t>(o + Offsets::BasePart::Primitive);
        }

        if (cls == "Model" || cls == "Tool" || cls == "Accessory") {
            uintptr_t pp = rbx::Read<uintptr_t>(o + Offsets::Model::PrimaryPart);
            if (pp && ClassIsBasePart(read_class(pp))) {
                return rbx::Read<uintptr_t>(pp + Offsets::BasePart::Primitive);
            }
        }
        return 0;
    }

    static void scan_add(uintptr_t obj, int cat, const std::string& display, std::vector<CachedObj>& out) {
        if (!obj) return;

        uintptr_t prim = PrimOf(obj);
        if (!prim) return;

        V3 pos = rbx::Read<V3>(prim + Offsets::Primitive::Position);
        if (pos.x == 0.0f && pos.y == 0.0f && pos.z == 0.0f) return;

        V3 size = rbx::Read<V3>(prim + Offsets::Primitive::Size);

        if (cat == CAT_ITEM) {
            if (size.x > 15.0f || size.y > 15.0f || size.z > 15.0f) return;
            if (read_class(obj) == "Model" && !has_child(obj, "ModulePrompt")) return;
        }

        CachedObj c;
        c.addr = obj;
        c.cat = cat;
        c.display = display;
        c.prim = prim;
        c.pos = pos;
        c.size = size;
        out.push_back(c);

        if (cat == CAT_ENTITY) {
            std::lock_guard<std::mutex> lock(g_mutex);
            if (!g_notified.count(display)) {
                g_notified.insert(display);
                g_pending_notifs.insert(display);
            }
        }
    }

    static void scan_node(uintptr_t node, std::vector<CachedObj>& out, int depth) {
        if (!node || depth > 8) return;

        uintptr_t vec = rbx::Read<uintptr_t>(node + Offsets::Instance::ChildrenStart);
        if (!vec) return;

        uintptr_t b = rbx::Read<uintptr_t>(vec);
        uintptr_t e = rbx::Read<uintptr_t>(vec + 8);
        if (!b || !e || e <= b) return;

        size_t n = (e - b) / 16;
        if (n == 0 || n > 500) return;

        for (size_t i = 0; i < n; i++) {
            uintptr_t child = rbx::Read<uintptr_t>(b + i * 16);
            if (!child) continue;

            std::string name = read_name(child);
            std::string cls = read_class(child);

            if (name == "Door" && cls == "Model") {
                uintptr_t parent = rbx::Read<uintptr_t>(child + Offsets::Instance::Parent);
                if (parent && read_name(parent) != "") {
                    scan_add(child, CAT_DOOR, "Door", out);
                }
            }
            else {
                auto hit = HidingTable().find(name);
                if (hit != HidingTable().end()) { scan_add(child, CAT_HIDING, hit->second, out); continue; }

                auto cit = ChestTable().find(name);
                if (cit != ChestTable().end()) { scan_add(child, CAT_CHEST, cit->second, out); continue; }

                auto oit = ObjectiveTable().find(name);
                if (oit != ObjectiveTable().end()) { scan_add(child, CAT_OBJECTIVE, oit->second, out); continue; }

                auto iit = ItemTable().find(name);
                if (iit != ItemTable().end()) { scan_add(child, CAT_ITEM, iit->second, out); continue; }

                auto sit = StairwellTable().find(name);
                if (sit != StairwellTable().end()) { scan_add(child, CAT_STAIRWELL, sit->second, out); continue; }

                auto ait = ArchivesTable().find(name);
                if (ait != ArchivesTable().end()) { scan_add(child, CAT_ARCHIVES, ait->second, out); continue; }

                if (name == "GoldPile" || name == "StardustPickup") {
                    scan_add(child, CAT_CURRENCY, name == "GoldPile" ? "Gold Pile" : "Stardust", out);
                    continue;
                }
            }

            if (cls == "Model" || cls == "Folder" || cls == "Accessory" || cls == "Configuration") {
                scan_node(child, out, depth + 1);
            }
        }
    }

    static void do_scan() {
        std::vector<CachedObj> fresh;
        fresh.reserve(1024);

        uintptr_t fdm = rbx::Read<uintptr_t>(rbx::g_base + Offsets::FakeDataModel::Pointer);
        if (!fdm) return;

        uintptr_t dm = rbx::Read<uintptr_t>(fdm + Offsets::FakeDataModel::RealDataModel);
        if (!dm) return;

        uintptr_t ws = rbx::Read<uintptr_t>(dm + Offsets::DataModel::Workspace);
        if (!ws) return;

        uintptr_t vec = rbx::Read<uintptr_t>(ws + Offsets::Instance::ChildrenStart);
        if (!vec) return;

        uintptr_t b = rbx::Read<uintptr_t>(vec);
        uintptr_t e = rbx::Read<uintptr_t>(vec + 8);
        if (!b || !e || e <= b) return;

        size_t n = (e - b) / 16;

        for (size_t i = 0; i < n; i++) {
            uintptr_t child = rbx::Read<uintptr_t>(b + i * 16);
            if (!child) continue;

            std::string name = read_name(child);

            auto it = EntityTable().find(name);
            if (it != EntityTable().end()) {
                scan_add(child, CAT_ENTITY, it->second.first, fresh);
            }

            if (name == "CurrentRooms") {
                scan_node(child, fresh, 0);
            }
        }

        std::lock_guard<std::mutex> lk(g_mutex);
        g_objects.swap(fresh);
    }

    static void scan_loop() {
        while (g_running) {
            std::this_thread::sleep_for(std::chrono::milliseconds(150));
            if (!s_enabled || (!IsDoorsGame() && !s_force_enable)) {
                std::lock_guard<std::mutex> lock(g_mutex);
                g_objects.clear();
                g_notified.clear();
                continue;
            }
            do_scan();
        }
    }

    void Init() {
        g_running = true;
        std::thread(scan_loop).detach();
    }

    void Tick() {
        if (!s_enabled || (!IsDoorsGame() && !s_force_enable)) return;

        if (s_tp_next_door) {
            uintptr_t hrp = GetLocalHRP();
            if (!hrp) return;

            V3 my_pos = rbx::Read<V3>(hrp + Offsets::Primitive::Position);

            CachedObj* best_door = nullptr;
            float min_dist = 1e9f;

            {
                std::lock_guard<std::mutex> lock(g_mutex);
                for (auto& obj : g_objects) {
                    if (obj.cat != CAT_DOOR) continue;
                    float dx = obj.pos.x - my_pos.x;
                    float dz = obj.pos.z - my_pos.z;
                    float d = sqrtf(dx * dx + dz * dz);
                    if (d < min_dist && d < 100.0f) {
                        min_dist = d;
                        best_door = &obj;
                    }
                }
            }

            if (best_door && min_dist > 2.5f) {
                V3 target = best_door->pos;
                target.y += 3.0f;

                V3 new_pos = {
                    my_pos.x + (target.x - my_pos.x) * s_farm_speed,
                    my_pos.y + (target.y - my_pos.y) * s_farm_speed,
                    my_pos.z + (target.z - my_pos.z) * s_farm_speed
                };

                rbx::Write<V3>(hrp + Offsets::Primitive::Position, new_pos);
                rbx::Write<V3>(hrp + Offsets::Primitive::AssemblyLinearVelocity, { 0,0,0 });
            }
        }
    }

    void Shutdown() { g_running = false; }

    static bool w2s(const V3& w, V2& out, const V3& cp, const M3& cr, float sw, float sh, float fov) {
        float rx = w.x - cp.x, ry = w.y - cp.y, rz = w.z - cp.z;
        float r_x = cr.m[0], r_y = cr.m[3], r_z = cr.m[6];
        float u_x = cr.m[1], u_y = cr.m[4], u_z = cr.m[7];
        float b_x = cr.m[2], b_y = cr.m[5], b_z = cr.m[8];

        float x = rx * r_x + ry * r_y + rz * r_z;
        float y = rx * u_x + ry * u_y + rz * u_z;
        float z = -(rx * b_x + ry * b_y + rz * b_z);

        if (z <= 0.01f) return false;

        float aspect = sw / sh;
        float tan_half = tanf(fov * 0.5f);
        if (tan_half < 0.0001f) return false;

        out.x = (sw * 0.5f) * (1.0f + x / (z * tan_half * aspect));
        out.y = (sh * 0.5f) * (1.0f - y / (z * tan_half));
        return true;
    }

    void DrawVisuals(ImDrawList* dl) {
        if (!s_enabled) return;
        if (!IsDoorsGame() && !s_force_enable) return;

        {
            std::lock_guard<std::mutex> lock(g_mutex);
            for (const auto& name : g_pending_notifs) {
                for (auto& kv : EntityTable()) {
                    if (kv.second.first == name) {
                        notification::Add(kv.second.first, kv.second.second, 5.0f);
                        break;
                    }
                }
            }
            g_pending_notifs.clear();
        }

        HWND rbx_hwnd = FindWindowA(nullptr, "Roblox");
        if (!rbx_hwnd) rbx_hwnd = GetForegroundWindow();

        RECT cr = { 0, 0, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN) };
        if (rbx_hwnd) GetClientRect(rbx_hwnd, &cr);

        POINT tl = { 0, 0 };
        if (rbx_hwnd) ClientToScreen(rbx_hwnd, &tl);

        float sw = (float)cr.right;
        float sh = (float)cr.bottom;
        if (sw < 100.0f || sh < 100.0f) return;

        uintptr_t fdm = rbx::Read<uintptr_t>(rbx::g_base + Offsets::FakeDataModel::Pointer);
        if (!fdm) return;
        uintptr_t dm = rbx::Read<uintptr_t>(fdm + Offsets::FakeDataModel::RealDataModel);
        if (!dm) return;
        uintptr_t ws = rbx::Read<uintptr_t>(dm + Offsets::DataModel::Workspace);
        if (!ws) return;
        uintptr_t cam = rbx::Read<uintptr_t>(ws + Offsets::Workspace::CurrentCamera);
        if (!cam) return;

        V3 cam_pos = rbx::Read<V3>(cam + Offsets::Camera::Position);
        M3 cam_rot = rbx::Read<M3>(cam + Offsets::Camera::Rotation);
        float fov = rbx::Read<float>(cam + Offsets::Camera::FieldOfView);

        if (fov > 3.0f) fov = fov * 3.14159265f / 180.0f;
        else if (fov < 0.05f) fov = 1.22173f;

        ImVec2 io_mouse = ImGui::GetIO().MousePos;
        float dt = ImGui::GetIO().DeltaTime;

        dl->PushClipRect(ImVec2((float)tl.x, (float)tl.y), ImVec2((float)tl.x + sw, (float)tl.y + sh), true);

        std::lock_guard<std::mutex> lock(g_mutex);
        std::unordered_set<uintptr_t> currently_rendered;

        for (const auto& obj : g_objects) {
            if (obj.cat == CAT_ENTITY && !s_esp_entities) continue;
            if (obj.cat == CAT_OBJECTIVE && !s_esp_objectives) continue;
            if (obj.cat == CAT_DOOR && !s_esp_doors) continue;
            if (obj.cat == CAT_HIDING && !s_esp_hiding) continue;
            if (obj.cat == CAT_CHEST && !s_esp_chests) continue;
            if (obj.cat == CAT_ITEM && !s_esp_items) continue;
            if (obj.cat == CAT_CURRENCY && !s_esp_currency) continue;
            if (obj.cat == CAT_STAIRWELL && !s_esp_stairwell) continue;
            if (obj.cat == CAT_ARCHIVES && !s_esp_archives) continue;

            float dx = obj.pos.x - cam_pos.x;
            float dy = obj.pos.y - cam_pos.y;
            float dz = obj.pos.z - cam_pos.z;
            float dist = sqrtf(dx * dx + dy * dy + dz * dz);

            if (obj.cat != CAT_ENTITY && dist > s_max_dist) continue;
            if (dist < 1.0f) continue;

            V3 top_pos = obj.pos; top_pos.y += obj.size.y / 2.0f;
            V3 bot_pos = obj.pos; bot_pos.y -= obj.size.y / 2.0f;

            V2 top_screen, bot_screen;
            if (!w2s(top_pos, top_screen, cam_pos, cam_rot, sw, sh, fov)) continue;
            if (!w2s(bot_pos, bot_screen, cam_pos, cam_rot, sw, sh, fov)) continue;

            float sx = (float)tl.x + top_screen.x;
            float sy = (float)tl.y + top_screen.y;

            currently_rendered.insert(obj.addr);
            if (g_alpha_cache.find(obj.addr) == g_alpha_cache.end()) g_alpha_cache[obj.addr] = 0.0f;

            float& alpha = g_alpha_cache[obj.addr];
            alpha += dt * 5.0f;
            if (alpha > 1.0f) alpha = 1.0f;

            float box_h = abs(bot_screen.y - top_screen.y);
            if (box_h < 12.0f) box_h = 12.0f;
            float box_w = box_h * 0.6f;

            if (obj.cat == CAT_DOOR) box_w = box_h * 0.8f;
            if (box_w < 12.0f) box_w = 12.0f;

            ImVec2 tl_box(sx - box_w / 2, sy);
            ImVec2 br_box(sx + box_w / 2, sy + box_h);

            ImVec4 base_col;
            if (obj.cat == CAT_ENTITY) base_col = *(ImVec4*)c_entity;
            else if (obj.cat == CAT_OBJECTIVE) base_col = *(ImVec4*)c_objective;
            else if (obj.cat == CAT_DOOR) base_col = *(ImVec4*)c_door;
            else if (obj.cat == CAT_HIDING) base_col = *(ImVec4*)c_hiding;
            else if (obj.cat == CAT_CHEST) base_col = *(ImVec4*)c_chest;
            else if (obj.cat == CAT_ITEM) base_col = *(ImVec4*)c_item;
            else if (obj.cat == CAT_CURRENCY) base_col = *(ImVec4*)c_currency;
            else if (obj.cat == CAT_STAIRWELL) base_col = *(ImVec4*)c_stairwell;
            else if (obj.cat == CAT_ARCHIVES) base_col = *(ImVec4*)c_archives;
            else base_col = ImVec4(1, 1, 1, 1);

            base_col.w *= alpha;
            ImU32 color = ImGui::ColorConvertFloat4ToU32(base_col);

            if (s_show_tracers) {
                ImVec2 start_pos;
                if (s_tracer_origin == 0) start_pos = ImVec2((float)tl.x + sw / 2, (float)tl.y + sh);
                else if (s_tracer_origin == 1) start_pos = ImVec2((float)tl.x + sw / 2, (float)tl.y);
                else if (s_tracer_origin == 2) start_pos = ImVec2((float)tl.x + sw / 2, (float)tl.y + sh / 2);
                else start_pos = io_mouse;

                dl->AddLine(start_pos, ImVec2(sx, sy + box_h / 2), color, s_tracer_thickness);
            }

            if (s_draw_path && obj.cat == CAT_DOOR && dist < 100.0f) {
                dl->AddLine(ImVec2((float)tl.x + sw / 2, (float)tl.y + sh), ImVec2(sx, sy + box_h / 2), color, 2.0f);
            }

            float len = box_w * 0.3f;
            float thick = 1.5f;

            dl->AddLine(ImVec2(tl_box.x, tl_box.y), ImVec2(tl_box.x + len, tl_box.y), color, thick);
            dl->AddLine(ImVec2(tl_box.x, tl_box.y), ImVec2(tl_box.x, tl_box.y + len), color, thick);
            dl->AddLine(ImVec2(br_box.x, tl_box.y), ImVec2(br_box.x - len, tl_box.y), color, thick);
            dl->AddLine(ImVec2(br_box.x, tl_box.y), ImVec2(br_box.x, tl_box.y + len), color, thick);
            dl->AddLine(ImVec2(tl_box.x, br_box.y), ImVec2(tl_box.x + len, br_box.y), color, thick);
            dl->AddLine(ImVec2(tl_box.x, br_box.y), ImVec2(tl_box.x, br_box.y - len), color, thick);
            dl->AddLine(ImVec2(br_box.x, br_box.y), ImVec2(br_box.x - len, br_box.y), color, thick);
            dl->AddLine(ImVec2(br_box.x, br_box.y), ImVec2(br_box.x, br_box.y - len), color, thick);

            if (s_show_names || s_show_dist) {
                std::string label = obj.display;
                if (s_show_dist) {
                    char buf[64];
                    sprintf_s(buf, " [%dm]", (int)dist);
                    label += buf;
                }

                ImVec2 ts = ImGui::CalcTextSize(label.c_str());
                ImVec2 tp(sx - ts.x / 2, tl_box.y - ts.y - 2);

                dl->AddText(ImVec2(tp.x + 1, tp.y + 1), IM_COL32(0, 0, 0, (int)(255 * alpha)), label.c_str());
                dl->AddText(tp, color, label.c_str());
            }
        }

        for (auto it = g_alpha_cache.begin(); it != g_alpha_cache.end(); ) {
            if (currently_rendered.find(it->first) == currently_rendered.end()) {
                it->second -= dt * 3.0f;
                if (it->second <= 0.0f) it = g_alpha_cache.erase(it);
                else ++it;
            }
            else {
                ++it;
            }
        }

        dl->PopClipRect();
    }

    void DrawTab() {
        if (!IsDoorsGame() && !s_force_enable) {
            ImGui::TextColored(ImVec4(1, 0, 0, 1), "Not in a supported Doors game.");
            ImGui::TextDisabled("Place IDs: 6839171747 / 18352758168 / 16945970239");
            ImGui::Checkbox("Force Enable (Test)", &s_force_enable);
            return;
        }

        ImGui::Checkbox("Enable Module", &s_enabled);
        ImGui::BeginDisabled(!s_enabled);

        if (ImGui::BeginTabBar("##DoorsSubTabs", ImGuiTabBarFlags_None)) {
            if (ImGui::BeginTabItem("Main")) {
                ImGui::Spacing();
                ImGui::TextUnformatted("Auto Farm");
                ImGui::Separator();
                ImGui::Checkbox("Smooth TP Next Door", &s_tp_next_door);
                if (s_tp_next_door) {
                    ImGui::SetNextItemWidth(-1);
                    ImGui::SliderFloat("##fspeed", &s_farm_speed, 0.05f, 0.5f, "Speed: %.2f");
                }
                ImGui::Checkbox("Draw Path Line", &s_draw_path);

                ImGui::Spacing();
                ImGui::TextUnformatted("General Settings");
                ImGui::Separator();
                ImGui::SetNextItemWidth(-1);
                ImGui::SliderFloat("##dist", &s_max_dist, 10.0f, 500.0f, "Max Distance (Non-Entity): %.0f");
                ImGui::Checkbox("Show Names", &s_show_names);
                ImGui::Checkbox("Show Distance", &s_show_dist);

                ImGui::EndTabItem();
            }

            if (ImGui::BeginTabItem("ESP")) {
                ImGui::Spacing();

                ImGui::Columns(2, "##esp_cols", false);

                ImGui::Checkbox("Entities", &s_esp_entities);
                ImGui::SameLine(); ImGui::ColorEdit4("##c1", c_entity, ImGuiColorEditFlags_NoInputs);

                ImGui::Checkbox("Objectives", &s_esp_objectives);
                ImGui::SameLine(); ImGui::ColorEdit4("##c2", c_objective, ImGuiColorEditFlags_NoInputs);

                ImGui::Checkbox("Doors", &s_esp_doors);
                ImGui::SameLine(); ImGui::ColorEdit4("##c3", c_door, ImGuiColorEditFlags_NoInputs);

                ImGui::Checkbox("Hiding Spots", &s_esp_hiding);
                ImGui::SameLine(); ImGui::ColorEdit4("##c4", c_hiding, ImGuiColorEditFlags_NoInputs);

                ImGui::NextColumn();

                ImGui::Checkbox("Chests", &s_esp_chests);
                ImGui::SameLine(); ImGui::ColorEdit4("##c5", c_chest, ImGuiColorEditFlags_NoInputs);

                ImGui::Checkbox("Items", &s_esp_items);
                ImGui::SameLine(); ImGui::ColorEdit4("##c6", c_item, ImGuiColorEditFlags_NoInputs);

                ImGui::Checkbox("Currency", &s_esp_currency);
                ImGui::SameLine(); ImGui::ColorEdit4("##c7", c_currency, ImGuiColorEditFlags_NoInputs);

                ImGui::Columns(1);

                ImGui::Spacing();
                ImGui::TextUnformatted("Tracers");
                ImGui::Separator();
                ImGui::Checkbox("Enable Tracers", &s_show_tracers);
                if (s_show_tracers) {
                    ImGui::SetNextItemWidth(-1);
                    ImGui::Combo("##origin", &s_tracer_origin, "Bottom\0Top\0Center\0Mouse\0");
                    ImGui::SetNextItemWidth(-1);
                    ImGui::SliderFloat("Thickness##trac", &s_tracer_thickness, 0.5f, 5.0f, "%.1f");
                }
                ImGui::EndTabItem();
            }

            if (ImGui::BeginTabItem("Extras")) {
                ImGui::Spacing();
                ImGui::TextUnformatted("Stairwell");
                ImGui::Separator();
                ImGui::Checkbox("Stairwell ESP (Crushers, Meld, etc.)", &s_esp_stairwell);
                ImGui::SameLine(); ImGui::ColorEdit4("##c8", c_stairwell, ImGuiColorEditFlags_NoInputs);

                ImGui::Spacing();
                ImGui::TextUnformatted("Archives");
                ImGui::Separator();
                ImGui::Checkbox("Archives ESP (Boxes, Fih Tank, Clock)", &s_esp_archives);
                ImGui::SameLine(); ImGui::ColorEdit4("##c9", c_archives, ImGuiColorEditFlags_NoInputs);

                ImGui::EndTabItem();
            }

            ImGui::EndTabBar();
        }

        ImGui::EndDisabled();
    }
}