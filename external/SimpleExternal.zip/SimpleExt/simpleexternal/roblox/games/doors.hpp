#pragma once
#include "imgui.h"

namespace doors {
    void Init();
    void Tick();
    void DrawVisuals(ImDrawList* dl);
    void DrawTab();
    void Shutdown();

    bool IsDoorsGame();
}