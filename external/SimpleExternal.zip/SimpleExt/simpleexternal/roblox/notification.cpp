#include "notification.hpp"
#include "imgui.h"
#include <vector>
#include <string>
#include <algorithm>

namespace notification {
    struct Item {
        std::string title;
        std::string body;
        float expire_time;
        float duration;
        float anim_x;
    };

    static std::vector<Item> g_notifications;

    void Add(const std::string& title, const std::string& body, float time) {
        g_notifications.push_back({ title, body, (float)ImGui::GetTime() + time, time, 0.0f });
    }

    void Draw() {
        float now = (float)ImGui::GetTime();
        float dt = ImGui::GetIO().DeltaTime;

        g_notifications.erase(std::remove_if(g_notifications.begin(), g_notifications.end(),
            [now](const Item& i) { return now > i.expire_time; }), g_notifications.end());

        if (g_notifications.empty()) return;

        ImGuiIO& io = ImGui::GetIO();
        float start_y = 80.0f;
        float target_x = io.DisplaySize.x - 320.0f;

        ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 4.0f);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);

        for (size_t i = 0; i < g_notifications.size(); ++i) {
            auto& n = g_notifications[i];

            n.anim_x += (target_x - n.anim_x) * (dt * 10.0f);
            if (n.anim_x > target_x) n.anim_x = target_x;

            float alpha = 1.0f;
            if (now > n.expire_time - 0.5f) alpha = (n.expire_time - now) / 0.5f;
            if (alpha < 0.0f) alpha = 0.0f;

            ImGui::SetNextWindowPos(ImVec2(n.anim_x, start_y + i * 75.0f), ImGuiCond_Always);
            ImGui::SetNextWindowSize(ImVec2(300.0f, 65.0f), ImGuiCond_Always);
            ImGui::SetNextWindowBgAlpha(alpha * 0.95f);

            ImGui::Begin(("##notif" + std::to_string(i)).c_str(), nullptr,
                ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoFocusOnAppearing | ImGuiWindowFlags_NoNav);

            ImDrawList* dl = ImGui::GetWindowDrawList();
            ImVec2 p = ImGui::GetWindowPos();
            ImVec2 size = ImGui::GetWindowSize();

            dl->AddRectFilled(p, ImVec2(p.x + size.x, p.y + 22.0f), ImGui::GetColorU32(ImVec4(0.17f, 0.36f, 0.52f, alpha)), 4.0f, ImDrawFlags_RoundCornersTop);

            ImGui::SetCursorPos(ImVec2(8, 4));
            ImGui::TextColored(ImVec4(1, 1, 1, alpha), "%s", n.title.c_str());

            ImGui::SetCursorPos(ImVec2(8, 26));
            ImGui::TextColored(ImVec4(0.8f, 0.8f, 0.8f, alpha), "%s", n.body.c_str());

            ImGui::End();
        }

        ImGui::PopStyleVar(2);
    }
}