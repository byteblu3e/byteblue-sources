#pragma once
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX

#include <Windows.h>
#include <TlHelp32.h>
#include <cstdint>
#include <string>
#include <vector>

namespace rbx {
    inline HANDLE g_handle = nullptr;
    inline DWORD g_pid = 0;
    inline uintptr_t g_base = 0;

    inline void Detach() {
        if (g_handle && g_handle != INVALID_HANDLE_VALUE) {
            CloseHandle(g_handle);
        }
        g_handle = nullptr;
        g_pid = 0;
        g_base = 0;
    }

    inline bool alive() {
        if (!g_handle || g_handle == INVALID_HANDLE_VALUE) return false;
        DWORD code = 0;
        if (!GetExitCodeProcess(g_handle, &code)) return false;
        return code == STILL_ACTIVE;
    }

    inline DWORD find_pid(const wchar_t* exe) {
        HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        if (snap == INVALID_HANDLE_VALUE) return 0;

        PROCESSENTRY32W pe{};
        pe.dwSize = sizeof(pe);
        DWORD out = 0;

        if (Process32FirstW(snap, &pe)) {
            do {
                if (_wcsicmp(pe.szExeFile, exe) == 0) {
                    out = pe.th32ProcessID;
                    break;
                }
            } while (Process32NextW(snap, &pe));
        }
        CloseHandle(snap);
        return out;
    }

    inline uintptr_t find_base(DWORD pid) {
        HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, pid);
        if (snap == INVALID_HANDLE_VALUE) return 0;

        MODULEENTRY32W me{};
        me.dwSize = sizeof(me);
        uintptr_t out = 0;

        if (Module32FirstW(snap, &me)) {
            do {
                if (_wcsicmp(me.szModule, L"RobloxPlayerBeta.exe") == 0) {
                    out = (uintptr_t)me.modBaseAddr;
                    break;
                }
            } while (Module32NextW(snap, &me));
        }
        CloseHandle(snap);
        return out;
    }

    inline bool Attach(const wchar_t* exe = L"RobloxPlayerBeta.exe") {
        if (g_handle && g_handle != INVALID_HANDLE_VALUE) {
            if (alive()) return true;
            Detach();
        }

        DWORD pid = find_pid(exe);
        if (!pid) return false;

        HANDLE h = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pid);
        if (!h) h = OpenProcess(PROCESS_VM_READ | PROCESS_VM_WRITE | PROCESS_VM_OPERATION, FALSE, pid);
        if (!h) return false;

        uintptr_t base = find_base(pid);
        if (!base) {
            CloseHandle(h);
            return false;
        }

        g_handle = h;
        g_pid = pid;
        g_base = base;
        return true;
    }

    template <typename T>
    inline T Read(uintptr_t addr) {
        T out{};
        if (!g_handle || !addr) return out;
        SIZE_T got = 0;
        ReadProcessMemory(g_handle, (LPCVOID)addr, &out, sizeof(T), &got);
        return out;
    }

    template <typename T>
    inline bool Write(uintptr_t addr, const T& val) {
        if (!g_handle || !addr) return false;
        SIZE_T wrote = 0;
        return WriteProcessMemory(g_handle, (LPVOID)addr, &val, sizeof(T), &wrote) != 0;
    }

    inline std::string ReadStr(uintptr_t addr) {
        if (!addr || !g_handle) return {};
        uintptr_t len = Read<uintptr_t>(addr + 0x10);
        if (!len || len > 256) return {};

        std::string s(len, 0);
        SIZE_T got = 0;

        if (len >= 16) {
            uintptr_t p = Read<uintptr_t>(addr);
            if (!p) return {};
            ReadProcessMemory(g_handle, (LPCVOID)p, &s[0], len, &got);
        }
        else {
            ReadProcessMemory(g_handle, (LPCVOID)addr, &s[0], len, &got);
        }
        return s;
    }

    inline std::string ReadStdString(uintptr_t addr) {
        return ReadStr(addr);
    }
}