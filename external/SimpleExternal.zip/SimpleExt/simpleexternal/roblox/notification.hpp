#pragma once
#include <string>

namespace notification {
    void Add(const std::string& title, const std::string& body, float time = 5.0f);
    void Draw();
}