#include "functions.hpp"
#include "memory.hpp"
#include "offsets.hpp"

#include <Windows.h>
#include <mmsystem.h>
#include <thread>
#include <chrono>
#include <atomic>
#include <cstdio>
#include <cmath>

#pragma comment(lib, "winmm.lib")

namespace features {

    float walkspeed = 16.0f;
    float jumppower = 50.0f;
    float hipheight = 2.5f;

    bool  fly_enabled = false;
    float fly_speed = 60.0f;

    bool  noclip_enabled = false;
    bool  infinite_jump = false;

    float camera_fov = 0.0f;
    bool  gravity_enabled = false;
    float gravity_value = 196.2f;

    static uintptr_t dm = 0, players = 0, lp = 0, chr = 0, hum = 0;
    static uintptr_t hrp = 0;
    static std::atomic<bool> run{ false };
    static std::thread th_find, th_write;

    static std::string name_of(uintptr_t inst) {
        if (!inst) return "";
        uintptr_t nc = rbx::Read<uintptr_t>(inst + Offsets::Instance::NameContainer);
        if (!nc) return "";
        return rbx::ReadStr(nc + Offsets::Instance::Name);
    }

    static bool name_is(uintptr_t inst, const char* want) {
        return name_of(inst) == want;
    }

    static uintptr_t find_child(uintptr_t parent, const char* name) {
        if (!parent) return 0;
        uintptr_t vec = rbx::Read<uintptr_t>(parent + Offsets::Instance::ChildrenStart);
        if (!vec || vec < 0x10000) return 0;
        uintptr_t b = rbx::Read<uintptr_t>(vec);
        uintptr_t e = rbx::Read<uintptr_t>(vec + 8);
        if (!b || !e || e <= b) return 0;
        size_t n = (e - b) / 16;
        if (n == 0 || n > 5000) return 0;
        for (size_t i = 0; i < n; i++) {
            uintptr_t c = rbx::Read<uintptr_t>(b + i * 16);
            if (c && name_is(c, name)) return c;
        }
        return 0;
    }

    static uintptr_t find_dm() {
        if (!rbx::g_base) return 0;
        uintptr_t fdm = rbx::Read<uintptr_t>(rbx::g_base + Offsets::FakeDataModel::Pointer);
        if (!fdm || fdm < 0x10000) return 0;
        uintptr_t real = rbx::Read<uintptr_t>(fdm + Offsets::FakeDataModel::RealDataModel);
        if (!real || real < 0x10000) return 0;
        return real;
    }

    struct V3 { float x, y, z; };
    struct M3 { float m[9]; };

    static V3 cross(const V3& a, const V3& b) {
        return { a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x };
    }
    static V3 normalize(V3 v) {
        float l = sqrtf(v.x * v.x + v.y * v.y + v.z * v.z);
        if (l < 0.0001f) return { 0,0,0 };
        return { v.x / l, v.y / l, v.z / l };
    }

    static void do_fly() {
        if (!fly_enabled || !hrp || !hum) return;

        uintptr_t ws = rbx::Read<uintptr_t>(dm + Offsets::DataModel::Workspace);
        if (!ws) return;
        uintptr_t cam = rbx::Read<uintptr_t>(ws + Offsets::Workspace::CurrentCamera);
        if (!cam) return;

        M3 mat = rbx::Read<M3>(cam + Offsets::Camera::Rotation);
        V3 fwd = normalize({ -mat.m[2], -mat.m[5], -mat.m[8] });
        if (fwd.x == 0.0f && fwd.y == 0.0f && fwd.z == 0.0f) return;

        const V3 world_up{ 0, 1, 0 };
        V3 right = normalize(cross(fwd, world_up));
        V3 up = normalize(cross(right, fwd));

        float vx = 0, vy = 0, vz = 0;
        if (GetAsyncKeyState('W') & 0x8000) { vx += fwd.x;   vy += fwd.y;   vz += fwd.z; }
        if (GetAsyncKeyState('S') & 0x8000) { vx -= fwd.x;   vy -= fwd.y;   vz -= fwd.z; }
        if (GetAsyncKeyState('D') & 0x8000) { vx += right.x; vy += right.y; vz += right.z; }
        if (GetAsyncKeyState('A') & 0x8000) { vx -= right.x; vy -= right.y; vz -= right.z; }
        if (GetAsyncKeyState(VK_SPACE) & 0x8000) { vx += up.x;    vy += up.y;    vz += up.z; }
        if (GetAsyncKeyState(VK_LCONTROL) & 0x8000) { vx -= up.x;    vy -= up.y;    vz -= up.z; }

        V3 dir = normalize({ vx, vy, vz });
        float sp = fly_speed;
        V3 vel{ dir.x * sp, dir.y * sp, dir.z * sp };

        uintptr_t prim = rbx::Read<uintptr_t>(hrp + Offsets::BasePart::Primitive);
        if (!prim || prim < 0x10000) return;
        rbx::Write<float>(prim + Offsets::Primitive::AssemblyLinearVelocity, vel.x);
        rbx::Write<float>(prim + Offsets::Primitive::AssemblyLinearVelocity + 4, vel.y);
        rbx::Write<float>(prim + Offsets::Primitive::AssemblyLinearVelocity + 8, vel.z);
    }

    static void set_collide(uintptr_t part, bool collide) {
        uintptr_t prim = rbx::Read<uintptr_t>(part + Offsets::BasePart::Primitive);
        if (!prim || prim < 0x10000 || prim > 0x7FFFFFFFFFFF) return;
        uintptr_t flags_addr = prim + Offsets::Primitive::Flags;
        uint8_t f = rbx::Read<uint8_t>(flags_addr);
        if (collide) f |= (uint8_t)Offsets::PrimitiveFlags::CanCollide;
        else         f &= (uint8_t)~Offsets::PrimitiveFlags::CanCollide;
        rbx::Write<uint8_t>(flags_addr, f);
    }

    static void do_noclip(bool on) {
        if (!chr) return;
        uintptr_t vec = rbx::Read<uintptr_t>(chr + Offsets::Instance::ChildrenStart);
        if (!vec || vec < 0x10000) return;
        uintptr_t b = rbx::Read<uintptr_t>(vec);
        uintptr_t e = rbx::Read<uintptr_t>(vec + 8);
        if (!b || !e || e <= b) return;
        size_t n = (e - b) / 16;
        if (n == 0 || n > 200) return;
        for (size_t i = 0; i < n; i++) {
            uintptr_t c = rbx::Read<uintptr_t>(b + i * 16);
            if (!c) continue;
            set_collide(c, !on);
        }
    }

    static void do_infinite_jump() {
        if (!hum || !infinite_jump) return;
        rbx::Write<bool>(hum + Offsets::Humanoid::Jump, true);
    }

    static void do_fov() {
        if (camera_fov <= 0.0f || !dm) return;
        uintptr_t ws = rbx::Read<uintptr_t>(dm + Offsets::DataModel::Workspace);
        if (!ws) return;
        uintptr_t cam = rbx::Read<uintptr_t>(ws + Offsets::Workspace::CurrentCamera);
        if (!cam) return;
        rbx::Write<float>(cam + Offsets::Camera::FieldOfView, camera_fov);
    }

    static void do_gravity() {
        if (!gravity_enabled || !dm) return;
        uintptr_t ws = rbx::Read<uintptr_t>(dm + Offsets::DataModel::Workspace);
        if (!ws) return;
        uintptr_t world = rbx::Read<uintptr_t>(ws + Offsets::Workspace::World);
        if (!world) return;
        rbx::Write<float>(world + Offsets::World::Gravity, gravity_value);
    }

    static void scan_loop() {
        using namespace std::chrono_literals;
        while (run) {
            if (!rbx::alive()) {
                rbx::Detach();
                if (!rbx::Attach()) { std::this_thread::sleep_for(1200ms); continue; }
            }
            dm = find_dm();
            if (dm) {
                players = find_child(dm, "Players");
                if (players) {
                    lp = rbx::Read<uintptr_t>(players + Offsets::Player::LocalPlayer);
                    if (lp) {
                        chr = rbx::Read<uintptr_t>(lp + Offsets::Player::ModelInstance);
                        hum = chr ? find_child(chr, "Humanoid") : 0;
                        hrp = hum ? rbx::Read<uintptr_t>(hum + Offsets::Humanoid::HumanoidRootPart) : 0;
                        if (!hrp && chr) hrp = find_child(chr, "HumanoidRootPart");
                    }
                }
            }
            std::this_thread::sleep_for(100ms);
        }
    }

    static bool s_noclip_was_on = false;

    static void write_loop() {
        timeBeginPeriod(1);
        while (run) {
            if (hum) {
                rbx::Write<float>(hum + Offsets::Humanoid::WalkspeedCheck, walkspeed);
                rbx::Write<float>(hum + Offsets::Humanoid::Walkspeed, walkspeed);
                rbx::Write<bool >(hum + Offsets::Humanoid::UseJumpPower, true);
                rbx::Write<float>(hum + Offsets::Humanoid::JumpPower, jumppower);
                rbx::Write<float>(hum + Offsets::Humanoid::HipHeight, hipheight);

                do_infinite_jump();
            }

            if (noclip_enabled && chr) {
                static DWORD last_noclip = 0;
                DWORD now = GetTickCount();
                if (!s_noclip_was_on || now - last_noclip > 1000) {
                    do_noclip(true);
                    s_noclip_was_on = true;
                    last_noclip = now;
                }
            }
            else if (s_noclip_was_on && chr) {
                do_noclip(false);
                s_noclip_was_on = false;
            }

            if (fly_enabled) do_fly();
            do_fov();
            do_gravity();

            std::this_thread::sleep_for(std::chrono::milliseconds(1));
        }
        timeEndPeriod(1);

        if (chr && s_noclip_was_on) do_noclip(false);
        if (fly_enabled && hrp) {
            uintptr_t prim = rbx::Read<uintptr_t>(hrp + Offsets::BasePart::Primitive);
            if (prim) {
                rbx::Write<float>(prim + Offsets::Primitive::AssemblyLinearVelocity, 0.f);
                rbx::Write<float>(prim + Offsets::Primitive::AssemblyLinearVelocity + 4, 0.f);
                rbx::Write<float>(prim + Offsets::Primitive::AssemblyLinearVelocity + 8, 0.f);
            }
        }
    }

    void Start() {
        if (run.exchange(true)) return;
        th_find = std::thread(scan_loop);
        th_write = std::thread(write_loop);
    }

    void Stop() {
        if (!run.exchange(false)) return;
        if (th_find.joinable())  th_find.join();
        if (th_write.joinable()) th_write.join();
        rbx::Detach();
    }

    void Tick() {}
    bool Attached() { return rbx::alive(); }
    bool Ready() { return hum != 0; }
    uintptr_t HumanoidAddr() { return hum; }

    static uintptr_t players_svc() {
        uintptr_t d = find_dm();
        if (!d) return 0;
        return find_child(d, "Players");
    }

    static uintptr_t local_player() {
        uintptr_t p = players_svc();
        if (!p) return 0;
        return rbx::Read<uintptr_t>(p + Offsets::Player::LocalPlayer);
    }

    uint64_t LocalUserId() {
        uintptr_t l = local_player();
        if (!l) return 0;
        return rbx::Read<uint64_t>(l + Offsets::Player::UserId);
    }

    std::string LocalName() {
        uintptr_t l = local_player();
        return name_of(l);
    }

    std::string PlaceName() {
        uintptr_t d = find_dm();
        if (!d) return "";
        std::string n = name_of(d);
        if (n.empty()) return "Main Menu";
        if (n.find("LuaApp") != std::string::npos) return "Main Menu";
        return n;
    }

    uint64_t PlaceId() {
        uintptr_t d = find_dm();
        if (!d) return 0;
        return rbx::Read<uint64_t>(d + Offsets::DataModel::PlaceId);
    }

    std::string ServerId() {
        uintptr_t d = find_dm();
        if (!d) return "";
        return rbx::ReadStr(d + Offsets::DataModel::JobId);
    }
}