#pragma once
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <Windows.h>
#include <winhttp.h>
#include <wincodec.h>
#include <d3d11.h>
#include <string>
#include <vector>
#include <unordered_map>
#include <mutex>
#include <thread>
#include <cstdint>

#pragma comment(lib, "winhttp.lib")
#pragma comment(lib, "windowscodecs.lib")

namespace assets {

    struct Image {
        ID3D11ShaderResourceView* srv = nullptr;
        int w = 0, h = 0;
    };

    // Copies out the image under lock; returns false if not loaded yet.
    // out is only touched if the function returns true.
    bool GetAvatar(uint64_t userId, Image& out);
    void RequestAvatar(uint64_t userId);

    bool GetAvatarFull(uint64_t userId, Image& out);
    void RequestAvatarFull(uint64_t userId);

    bool GetGameIcon(uint64_t placeId, Image& out);
    void RequestGameIcon(uint64_t placeId);

    void Drain(ID3D11Device* dev);
    bool Busy();

    // Releases all SRVs; call once at shutdown (before device release).
    void Shutdown();
}