#include "assets.hpp"

#include <cstring>
#include <cstdio>

namespace assets {

    struct Pending {
        std::vector<uint8_t> rgba;
        int w = 0, h = 0;
        uint64_t id = 0;
        int kind = 0;   // 0 = avatar head, 1 = avatar full, 2 = game icon
    };

    struct Store {
        std::mutex mu;
        std::unordered_map<uint64_t, Image> avatars;
        std::unordered_map<uint64_t, Image> avatars_full;
        std::unordered_map<uint64_t, Image> games;
        std::unordered_map<uint64_t, bool> req_head;
        std::unordered_map<uint64_t, bool> req_full;
        std::unordered_map<uint64_t, bool> req_game;
        std::vector<Pending> pending;
        int inflight = 0;
    };

    static Store& S() { static Store s; return s; }

    static std::string json_str(const std::string& j, const std::string& key) {
        std::string pat = "\"" + key + "\":\"";
        auto p = j.find(pat);
        if (p == std::string::npos) return "";
        p += pat.size();
        auto e = j.find('"', p);
        if (e == std::string::npos) return "";
        return j.substr(p, e - p);
    }

    static std::wstring widen(const std::string& s) {
        if (s.empty()) return {};
        int n = MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), nullptr, 0);
        if (n <= 0) return {};
        std::wstring w(n, L'\0');
        MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), w.data(), n);
        return w;
    }

    static bool http_get(const std::wstring& host, const std::wstring& path, std::vector<uint8_t>& out) {
        out.clear();
        HINTERNET s = WinHttpOpen(L"Mozilla/5.0", WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY,
            WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
        if (!s) return false;

        WinHttpSetTimeouts(s, 5000, 5000, 5000, 8000);

        HINTERNET c = WinHttpConnect(s, host.c_str(), INTERNET_DEFAULT_HTTPS_PORT, 0);
        if (!c) {
            WinHttpCloseHandle(s);
            return false;
        }

        HINTERNET r = WinHttpOpenRequest(c, L"GET", path.c_str(), nullptr,
            WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES,
            WINHTTP_FLAG_SECURE);
        if (!r) {
            WinHttpCloseHandle(c);
            WinHttpCloseHandle(s);
            return false;
        }

        BOOL ok = WinHttpSendRequest(r, WINHTTP_NO_ADDITIONAL_HEADERS, 0,
            WINHTTP_NO_REQUEST_DATA, 0, 0, 0);
        if (ok) ok = WinHttpReceiveResponse(r, nullptr);
        if (!ok) {
            WinHttpCloseHandle(r);
            WinHttpCloseHandle(c);
            WinHttpCloseHandle(s);
            return false;
        }

        DWORD status = 0, sz = sizeof(status);
        if (!WinHttpQueryHeaders(r,
            WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER,
            WINHTTP_HEADER_NAME_BY_INDEX, &status, &sz, WINHTTP_NO_HEADER_INDEX)
            || status != 200) {
            WinHttpCloseHandle(r);
            WinHttpCloseHandle(c);
            WinHttpCloseHandle(s);
            return false;
        }

        DWORD avail = 0;
        while (WinHttpQueryDataAvailable(r, &avail) && avail > 0) {
            size_t old = out.size();
            if (old + avail > (8u << 20)) break; // 8MB cap
            out.resize(old + avail);
            DWORD got = 0;
            if (!WinHttpReadData(r, out.data() + old, avail, &got)) {
                out.resize(old);
                break;
            }
            out.resize(old + got);
        }

        WinHttpCloseHandle(r);
        WinHttpCloseHandle(c);
        WinHttpCloseHandle(s);
        return !out.empty();
    }

    static bool decode_png(const std::vector<uint8_t>& in, std::vector<uint8_t>& rgba, int& w, int& h) {
        if (in.empty()) return false;

        IWICImagingFactory* fac = nullptr;
        if (FAILED(CoCreateInstance(CLSID_WICImagingFactory, nullptr, CLSCTX_INPROC_SERVER,
            IID_PPV_ARGS(&fac))))
            return false;

        IWICStream* stream = nullptr;
        if (FAILED(fac->CreateStream(&stream)) || !stream) {
            fac->Release();
            return false;
        }

        if (FAILED(stream->InitializeFromMemory((BYTE*)in.data(), (DWORD)in.size()))) {
            stream->Release();
            fac->Release();
            return false;
        }

        IWICBitmapDecoder* dec = nullptr;
        if (FAILED(fac->CreateDecoderFromStream(stream, nullptr,
            WICDecodeMetadataCacheOnDemand, &dec)) || !dec) {
            stream->Release();
            fac->Release();
            return false;
        }

        IWICBitmapFrameDecode* frame = nullptr;
        if (FAILED(dec->GetFrame(0, &frame)) || !frame) {
            dec->Release();
            stream->Release();
            fac->Release();
            return false;
        }

        IWICFormatConverter* conv = nullptr;
        if (FAILED(fac->CreateFormatConverter(&conv)) || !conv) {
            frame->Release();
            dec->Release();
            stream->Release();
            fac->Release();
            return false;
        }

        if (FAILED(conv->Initialize(frame, GUID_WICPixelFormat32bppRGBA,
            WICBitmapDitherTypeNone, nullptr, 0.0, WICBitmapPaletteTypeCustom))) {
            conv->Release();
            frame->Release();
            dec->Release();
            stream->Release();
            fac->Release();
            return false;
        }

        UINT uw = 0, uh = 0;
        conv->GetSize(&uw, &uh);
        if (uw == 0 || uh == 0 || uw > 4096 || uh > 4096) {
            conv->Release();
            frame->Release();
            dec->Release();
            stream->Release();
            fac->Release();
            return false;
        }

        w = (int)uw; h = (int)uh;
        rgba.resize((size_t)w * h * 4);

        if (FAILED(conv->CopyPixels(nullptr, w * 4, (UINT)rgba.size(), rgba.data()))) {
            conv->Release();
            frame->Release();
            dec->Release();
            stream->Release();
            fac->Release();
            return false;
        }

        conv->Release();
        frame->Release();
        dec->Release();
        stream->Release();
        fac->Release();
        return true;
    }

    static ID3D11ShaderResourceView* upload(ID3D11Device* dev, const std::vector<uint8_t>& rgba, int w, int h) {
        if (!dev || rgba.empty() || w <= 0 || h <= 0) return nullptr;

        D3D11_TEXTURE2D_DESC td{};
        td.Width = w; td.Height = h;
        td.MipLevels = 1; td.ArraySize = 1;
        td.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
        td.SampleDesc.Count = 1;
        td.Usage = D3D11_USAGE_DEFAULT;
        td.BindFlags = D3D11_BIND_SHADER_RESOURCE;

        D3D11_SUBRESOURCE_DATA sd{};
        sd.pSysMem = rgba.data();
        sd.SysMemPitch = w * 4;

        ID3D11Texture2D* tex = nullptr;
        if (FAILED(dev->CreateTexture2D(&td, &sd, &tex))) return nullptr;

        ID3D11ShaderResourceView* srv = nullptr;
        dev->CreateShaderResourceView(tex, nullptr, &srv);
        tex->Release();
        return srv;
    }

    static bool fetch_image_url(const std::wstring& api_host, const std::wstring& api_path, std::vector<uint8_t>& out_png) {
        std::vector<uint8_t> body;
        if (!http_get(api_host, api_path, body)) return false;

        std::string js(body.begin(), body.end());
        std::string url = json_str(js, "imageUrl");
        if (url.empty()) return false;

        std::string https = "https://";
        if (url.find(https) != 0) return false;

        std::string rest = url.substr(https.size());
        size_t slash = rest.find('/');
        if (slash == std::string::npos) return false;

        std::string host = rest.substr(0, slash);
        std::string path = rest.substr(slash);

        return http_get(widen(host), widen(path), out_png);
    }

    static void finish(Pending&& pu) {
        std::lock_guard<std::mutex> lk(S().mu);
        S().pending.push_back(std::move(pu));
        S().inflight--;
    }

    static void fail() {
        std::lock_guard<std::mutex> lk(S().mu);
        S().inflight--;
    }

    static void fetch_avatar(uint64_t uid) {
        std::wstring path = L"/v1/users/avatar-headshot?userIds=" +
            std::to_wstring(uid) +
            L"&size=150x150&format=Png&isCircular=true&thumbnailType=HeadShot";

        std::vector<uint8_t> img;
        if (!fetch_image_url(L"thumbnails.roblox.com", path, img)) { fail(); return; }

        Pending pu;
        pu.id = uid;
        pu.kind = 0;

        if (!decode_png(img, pu.rgba, pu.w, pu.h)) { fail(); return; }
        finish(std::move(pu));
    }

    static void fetch_avatar_full(uint64_t uid) {
        std::wstring path = L"/v1/users/avatar?userIds=" +
            std::to_wstring(uid) +
            L"&size=420x420&format=Png&isCircular=false";

        std::vector<uint8_t> img;
        if (!fetch_image_url(L"thumbnails.roblox.com", path, img)) { fail(); return; }

        Pending pu;
        pu.id = uid;
        pu.kind = 1;

        if (!decode_png(img, pu.rgba, pu.w, pu.h)) { fail(); return; }
        finish(std::move(pu));
    }

    static void fetch_game(uint64_t place_id) {
        std::wstring path = L"/v1/places/gameicons?placeIds=" +
            std::to_wstring(place_id) +
            L"&returnPolicy=PlaceHolder&size=150x150&format=Png&isCircular=false";

        std::vector<uint8_t> img;
        if (!fetch_image_url(L"thumbnails.roblox.com", path, img)) { fail(); return; }

        Pending pu;
        pu.id = place_id;
        pu.kind = 2;

        if (!decode_png(img, pu.rgba, pu.w, pu.h)) { fail(); return; }
        finish(std::move(pu));
    }

    void RequestAvatar(uint64_t userId) {
        if (!userId) return;
        {
            std::lock_guard<std::mutex> lk(S().mu);
            if (S().req_head[userId]) return;
            S().req_head[userId] = true;
            S().inflight++;
        }
        std::thread([userId]() { fetch_avatar(userId); }).detach();
    }

    void RequestAvatarFull(uint64_t userId) {
        if (!userId) return;
        {
            std::lock_guard<std::mutex> lk(S().mu);
            if (S().req_full[userId]) return;
            S().req_full[userId] = true;
            S().inflight++;
        }
        std::thread([userId]() { fetch_avatar_full(userId); }).detach();
    }

    void RequestGameIcon(uint64_t placeId) {
        if (!placeId) return;
        {
            std::lock_guard<std::mutex> lk(S().mu);
            if (S().req_game[placeId]) return;
            S().req_game[placeId] = true;
            S().inflight++;
        }
        std::thread([placeId]() { fetch_game(placeId); }).detach();
    }

    void Drain(ID3D11Device* dev) {
        if (!dev) return;
        std::vector<Pending> local;
        {
            std::lock_guard<std::mutex> lk(S().mu);
            if (S().pending.empty()) return;
            local.swap(S().pending);
        }
        for (auto& pu : local) {
            ID3D11ShaderResourceView* srv = upload(dev, pu.rgba, pu.w, pu.h);
            if (!srv) continue;

            std::lock_guard<std::mutex> lk(S().mu);
            Image* dst = nullptr;
            if (pu.kind == 0)      dst = &S().avatars[pu.id];
            else if (pu.kind == 1) dst = &S().avatars_full[pu.id];
            else                   dst = &S().games[pu.id];

            if (dst->srv) dst->srv->Release();
            dst->srv = srv;
            dst->w = pu.w;
            dst->h = pu.h;
        }
    }

    bool GetAvatar(uint64_t userId, Image& out) {
        std::lock_guard<std::mutex> lk(S().mu);
        auto it = S().avatars.find(userId);
        if (it == S().avatars.end() || !it->second.srv) return false;
        out = it->second;
        return true;
    }

    bool GetAvatarFull(uint64_t userId, Image& out) {
        std::lock_guard<std::mutex> lk(S().mu);
        auto it = S().avatars_full.find(userId);
        if (it == S().avatars_full.end() || !it->second.srv) return false;
        out = it->second;
        return true;
    }

    bool GetGameIcon(uint64_t placeId, Image& out) {
        std::lock_guard<std::mutex> lk(S().mu);
        auto it = S().games.find(placeId);
        if (it == S().games.end() || !it->second.srv) return false;
        out = it->second;
        return true;
    }

    bool Busy() {
        std::lock_guard<std::mutex> lk(S().mu);
        return S().inflight > 0 || !S().pending.empty();
    }

    void Shutdown() {
        std::lock_guard<std::mutex> lk(S().mu);
        auto release_map = [](auto& m) {
            for (auto& kv : m) if (kv.second.srv) kv.second.srv->Release();
            m.clear();
            };
        release_map(S().avatars);
        release_map(S().avatars_full);
        release_map(S().games);
        S().pending.clear();
    }
}