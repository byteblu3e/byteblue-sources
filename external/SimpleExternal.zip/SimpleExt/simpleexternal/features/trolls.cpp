
// unfinished ur prob gonna fling urself

#include "trolls.hpp"
#include "memory.hpp"
#include "offsets.hpp"

#include <Windows.h>
#include <thread>
#include <mutex>
#include <vector>
#include <string>
#include <unordered_set>
#include <cmath>
#include <atomic>

namespace trolls {

    struct V3 { float x, y, z; };

    struct TargetPlayer {
        uintptr_t instance = 0;
        std::string name;
        uintptr_t character = 0;
        uintptr_t humanoid = 0;
        uintptr_t hrp = 0;
        bool alive = false;
    };

    static std::vector<TargetPlayer> g_players;
    static std::unordered_set<uintptr_t> g_selected;
    static std::mutex g_mutex;

    static int g_method = 0;
    static std::atomic<bool> g_fling_active{ false };
    static std::atomic<bool> g_running{ true };
    static std::atomic<bool> g_worker_active{ false };

    static std::string read_name(uintptr_t inst) {
        if (!inst) return "";
        uintptr_t nc = rbx::Read<uintptr_t>(inst + Offsets::Instance::NameContainer);
        if (!nc) return "";
        return rbx::ReadStr(nc + Offsets::Instance::Name);
    }

    static uintptr_t find_child(uintptr_t parent, const char* name) {
        if (!parent) return 0;

        uintptr_t vec = rbx::Read<uintptr_t>(parent + Offsets::Instance::ChildrenStart);
        if (!vec) return 0;

        uintptr_t b = rbx::Read<uintptr_t>(vec);
        uintptr_t e = rbx::Read<uintptr_t>(vec + 8);
        if (!b || !e || e <= b) return 0;

        size_t n = (e - b) / 16;
        for (size_t i = 0; i < n; i++) {
            uintptr_t c = rbx::Read<uintptr_t>(b + i * 16);
            if (c && read_name(c) == name) return c;
        }
        return 0;
    }

    static uintptr_t get_local_player() {
        uintptr_t fdm = rbx::Read<uintptr_t>(rbx::g_base + Offsets::FakeDataModel::Pointer);
        if (!fdm) return 0;

        uintptr_t dm = rbx::Read<uintptr_t>(fdm + Offsets::FakeDataModel::RealDataModel);
        if (!dm) return 0;

        uintptr_t players = find_child(dm, "Players");
        if (!players) return 0;

        return rbx::Read<uintptr_t>(players + Offsets::Player::LocalPlayer);
    }

    static bool valid_prim(uintptr_t p) {
        return p > 0x10000 && p < 0x7FFFFFFFFFFF && (p & 0x7) == 0;
    }

    static bool valid_vec3(const V3& v) {
        return std::isfinite(v.x) && std::isfinite(v.y) && std::isfinite(v.z) &&
            fabsf(v.x) < 1e6f && fabsf(v.y) < 1e6f && fabsf(v.z) < 1e6f;
    }

    static void scan_players() {
        std::vector<TargetPlayer> found;

        uintptr_t lp = get_local_player();
        if (!lp) return;

        uintptr_t players_svc = rbx::Read<uintptr_t>(lp + Offsets::Instance::Parent);
        if (!players_svc) return;

        uintptr_t vec = rbx::Read<uintptr_t>(players_svc + Offsets::Instance::ChildrenStart);
        if (!vec) return;

        uintptr_t b = rbx::Read<uintptr_t>(vec);
        uintptr_t e = rbx::Read<uintptr_t>(vec + 8);
        if (!b || !e || e <= b) return;

        size_t n = (e - b) / 16;

        for (size_t i = 0; i < n; i++) {
            uintptr_t child = rbx::Read<uintptr_t>(b + i * 16);
            if (!child || child == lp) continue;

            std::string name = read_name(child);
            if (name.empty()) name = "<unknown>";

            TargetPlayer tp;
            tp.instance = child;
            tp.name = name;

            uintptr_t char_inst = rbx::Read<uintptr_t>(child + Offsets::Player::ModelInstance);
            tp.character = char_inst;

            if (char_inst) {
                uintptr_t hum = find_child(char_inst, "Humanoid");
                tp.humanoid = hum;

                uintptr_t hrp = 0;
                if (hum) hrp = rbx::Read<uintptr_t>(hum + Offsets::Humanoid::HumanoidRootPart);
                if (!hrp) hrp = find_child(char_inst, "HumanoidRootPart");
                tp.hrp = hrp;

                if (hum) {
                    float hp = rbx::Read<float>(hum + Offsets::Humanoid::Health);
                    tp.alive = hp > 0.0f;
                }
            }
            found.push_back(std::move(tp));
        }

        std::lock_guard<std::mutex> lock(g_mutex);
        g_players = std::move(found);
    }

    static void scan_loop() {
        while (g_running.load()) {
            std::this_thread::sleep_for(std::chrono::milliseconds(500));
            if (rbx::alive()) scan_players();
        }
    }

    static void method_velocity(uintptr_t target_prim) {
        if (!valid_prim(target_prim)) return;

        V3 vel = { 9e7f, 9e8f, 9e7f };
        V3 rot = { 9e8f, 9e8f, 9e8f };

        rbx::Write<V3>(target_prim + Offsets::Primitive::AssemblyLinearVelocity, vel);
        rbx::Write<V3>(target_prim + Offsets::Primitive::AssemblyAngularVelocity, rot);
    }

    static void method_collision(uintptr_t local_prim, uintptr_t target_prim, V3 old_pos) {
        if (!valid_prim(local_prim) || !valid_prim(target_prim)) return;

        V3 t_pos = rbx::Read<V3>(target_prim + Offsets::Primitive::Position);
        if (!valid_vec3(t_pos)) return;

        rbx::Write<V3>(local_prim + Offsets::Primitive::Position, { t_pos.x, t_pos.y + 1.5f, t_pos.z });

        V3 vel = { 9e7f, 9e8f, 9e7f };
        V3 rot = { 9e8f, 9e8f, 9e8f };

        rbx::Write<V3>(local_prim + Offsets::Primitive::AssemblyLinearVelocity, vel);
        rbx::Write<V3>(local_prim + Offsets::Primitive::AssemblyAngularVelocity, rot);
        rbx::Write<V3>(target_prim + Offsets::Primitive::AssemblyLinearVelocity, vel);
        rbx::Write<V3>(target_prim + Offsets::Primitive::AssemblyAngularVelocity, rot);

        Sleep(16);

        rbx::Write<V3>(local_prim + Offsets::Primitive::AssemblyLinearVelocity, { 0, 0, 0 });
        rbx::Write<V3>(local_prim + Offsets::Primitive::AssemblyAngularVelocity, { 0, 0, 0 });
        rbx::Write<V3>(local_prim + Offsets::Primitive::Position, old_pos);

        Sleep(16);
    }

    static void method_teleport(uintptr_t target_prim) {
        if (!valid_prim(target_prim)) return;

        V3 cur = rbx::Read<V3>(target_prim + Offsets::Primitive::Position);
        if (!valid_vec3(cur)) return;

        V3 out = { cur.x + 5000.0f, cur.y + 5000.0f, cur.z + 5000.0f };

        rbx::Write<V3>(target_prim + Offsets::Primitive::Position, out);
        rbx::Write<V3>(target_prim + Offsets::Primitive::AssemblyLinearVelocity, { 9e7f, 9e7f, 9e7f });
    }

    static void fling_target(uintptr_t local_hrp, uintptr_t target_hrp, int method) {
        uintptr_t local_prim = rbx::Read<uintptr_t>(local_hrp + Offsets::BasePart::Primitive);
        if (!valid_prim(local_prim)) return;

        V3 old_pos = rbx::Read<V3>(local_prim + Offsets::Primitive::Position);
        if (!valid_vec3(old_pos)) return;

        DWORD start = GetTickCount();
        while (g_fling_active.load() && (GetTickCount() - start) < 2000) {
            uintptr_t target_prim = rbx::Read<uintptr_t>(target_hrp + Offsets::BasePart::Primitive);
            if (!valid_prim(target_prim)) break;

            uintptr_t curr_local_prim = rbx::Read<uintptr_t>(local_hrp + Offsets::BasePart::Primitive);
            if (!valid_prim(curr_local_prim)) break;

            if (method == 0 || method == 3) method_velocity(target_prim);
            if (method == 1 || method == 3) method_collision(curr_local_prim, target_prim, old_pos);
            if (method == 2 || method == 3) method_teleport(target_prim);

            if (method == 0 || method == 2) Sleep(30);
        }

        uintptr_t local_end_prim = rbx::Read<uintptr_t>(local_hrp + Offsets::BasePart::Primitive);
        if (valid_prim(local_end_prim)) {
            rbx::Write<V3>(local_end_prim + Offsets::Primitive::Position, old_pos);
            rbx::Write<V3>(local_end_prim + Offsets::Primitive::AssemblyLinearVelocity, { 0, 0, 0 });
            rbx::Write<V3>(local_end_prim + Offsets::Primitive::AssemblyAngularVelocity, { 0, 0, 0 });
        }
    }

    static void fling_worker_loop() {
        while (g_fling_active.load()) {
            uintptr_t lp = get_local_player();
            if (!lp) { Sleep(100); continue; }

            uintptr_t my_char = rbx::Read<uintptr_t>(lp + Offsets::Player::ModelInstance);
            if (!my_char) { Sleep(100); continue; }

            uintptr_t my_hum = find_child(my_char, "Humanoid");
            uintptr_t my_hrp = my_hum ? rbx::Read<uintptr_t>(my_hum + Offsets::Humanoid::HumanoidRootPart) : 0;
            if (!my_hrp) { Sleep(100); continue; }

            std::vector<TargetPlayer> targets;
            {
                std::lock_guard<std::mutex> lock(g_mutex);
                for (auto& p : g_players) {
                    if (g_selected.count(p.instance) && p.hrp && p.alive)
                        targets.push_back(p);
                }
            }

            if (targets.empty()) { Sleep(100); continue; }

            int method = g_method;
            for (auto& t : targets) {
                if (!g_fling_active.load()) break;
                fling_target(my_hrp, t.hrp, method);
                Sleep(100);
            }
            Sleep(500);
        }
    }

    void Init() {
        g_running = true;
        std::thread(scan_loop).detach();
    }

    void Tick() {
        bool expected = false;
        if (g_fling_active.load() && g_worker_active.compare_exchange_strong(expected, true)) {
            std::thread([]() {
                fling_worker_loop();
                g_worker_active.store(false);
                }).detach();
        }
    }

    void Shutdown() {
        g_running = false;
        g_fling_active = false;
    }

    void DrawTab() {
        ImGui::Spacing();

        bool fling = g_fling_active.load();
        if (ImGui::Checkbox("Enable Fling", &fling)) {
            g_fling_active.store(fling);
        }

        ImGui::Spacing();
        ImGui::TextUnformatted("Method:");
        ImGui::RadioButton("Velocity", &g_method, 0);
        ImGui::RadioButton("Collision", &g_method, 1);
        ImGui::RadioButton("Teleport", &g_method, 2);
        ImGui::RadioButton("All", &g_method, 3);

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::TextUnformatted("Targets:");

        if (ImGui::Button("Select All", ImVec2(100, 0))) {
            std::lock_guard<std::mutex> lock(g_mutex);
            for (auto& p : g_players) g_selected.insert(p.instance);
        }
        ImGui::SameLine();
        if (ImGui::Button("Clear", ImVec2(100, 0))) {
            std::lock_guard<std::mutex> lock(g_mutex);
            g_selected.clear();
        }

        ImGui::BeginChild("##targets", ImVec2(0, 0), true);
        {
            std::lock_guard<std::mutex> lock(g_mutex);
            if (g_players.empty()) {
                ImGui::TextDisabled("No players found.");
            }
            else {
                for (auto& p : g_players) {
                    bool sel = g_selected.count(p.instance) > 0;
                    std::string label = p.name;
                    if (!p.alive) label += " (dead)";
                    else if (!p.hrp) label += " (no char)";

                    if (ImGui::Checkbox(label.c_str(), &sel)) {
                        if (sel) g_selected.insert(p.instance);
                        else g_selected.erase(p.instance);
                    }
                }
            }
        }
        ImGui::EndChild();
    }
}