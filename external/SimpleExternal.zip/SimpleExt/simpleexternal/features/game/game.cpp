#include "game.hpp"
#include "memory.hpp"
#include "offsets.hpp"
#include "imgui.h"

#include <string>
#include <vector>
#include <cstdio>
#include <cctype>
#include <algorithm>

namespace game {

    struct InstanceNode {
        uintptr_t addr = 0;
        std::string name;
        std::string cls;
        std::vector<InstanceNode> children;
    };

    static InstanceNode g_root;
    static uintptr_t g_selected = 0;
    static char g_search[128] = "";
    static bool g_auto_refresh = false;
    static float g_refresh_timer = 0.0f;
    static bool g_needs_refresh = true;

    // ── Memory Helpers ───────────────────────────────────────────────────

    static std::string read_name(uintptr_t inst) {
        if (!inst) return "???";
        uintptr_t nc = rbx::Read<uintptr_t>(inst + Offsets::Instance::NameContainer);
        if (!nc || nc < 0x10000 || nc > 0x7FFFFFFFFFFF) return "???";
        std::string s = rbx::ReadStr(nc + Offsets::Instance::Name);
        if (s.empty()) return "???";
        return s;
    }

    static std::string read_class(uintptr_t inst) {
        if (!inst) return "Instance";
        uintptr_t cd = rbx::Read<uintptr_t>(inst + Offsets::Instance::ClassDescriptor);
        if (!cd || cd < 0x10000 || cd > 0x7FFFFFFFFFFF) return "Instance";

        std::string s = rbx::ReadStr(cd + Offsets::Instance::ClassName);
        if (!s.empty() && s != "???") return s;

        uintptr_t ptr = rbx::Read<uintptr_t>(cd + Offsets::Instance::ClassName);
        if (ptr && ptr > 0x10000) {
            char buf[64] = { 0 };
            SIZE_T bytes = 0;
            ReadProcessMemory(rbx::g_handle, (LPCVOID)ptr, buf, sizeof(buf) - 1, &bytes);
            if (bytes > 0) return std::string(buf);
        }
        return "Instance";
    }

    // ── Tree Builder ─────────────────────────────────────────────────────

    static void build_tree(InstanceNode& parent, int depth, int& count) {
        if (depth > 10 || count > 5000) return; // Limits to prevent freezing

        uintptr_t vec = rbx::Read<uintptr_t>(parent.addr + Offsets::Instance::ChildrenStart);
        if (!vec || vec < 0x10000) return;

        uintptr_t b = rbx::Read<uintptr_t>(vec);
        uintptr_t e = rbx::Read<uintptr_t>(vec + 8);
        if (!b || !e || e <= b) return;

        size_t n = (e - b) / 16;
        if (n == 0 || n > 5000) return;

        for (size_t i = 0; i < n; i++) {
            uintptr_t child = rbx::Read<uintptr_t>(b + i * 16);
            if (!child || child < 0x10000 || child > 0x7FFFFFFFFFFF) continue;

            InstanceNode node;
            node.addr = child;
            node.name = read_name(child);
            node.cls = read_class(child);

            count++;
            build_tree(node, depth + 1, count);
            parent.children.push_back(node);
        }
    }

    void Refresh() {
        g_root = InstanceNode();

        if (!rbx::g_base) return;
        uintptr_t fdm = rbx::Read<uintptr_t>(rbx::g_base + Offsets::FakeDataModel::Pointer);
        if (!fdm || fdm < 0x10000) return;

        uintptr_t dm = rbx::Read<uintptr_t>(fdm + Offsets::FakeDataModel::RealDataModel);
        if (!dm || dm < 0x10000) return;

        g_root.addr = dm;
        g_root.name = "Game";
        g_root.cls = "DataModel";

        int count = 0;

        // Load Workspace
        uintptr_t ws = rbx::Read<uintptr_t>(dm + Offsets::DataModel::Workspace);
        if (ws) {
            InstanceNode ws_node;
            ws_node.addr = ws;
            ws_node.name = "Workspace";
            ws_node.cls = "Workspace";
            build_tree(ws_node, 1, count);
            g_root.children.push_back(ws_node);
        }

        // Load Players
        uintptr_t vec = rbx::Read<uintptr_t>(dm + Offsets::Instance::ChildrenStart);
        if (vec) {
            uintptr_t b = rbx::Read<uintptr_t>(vec);
            uintptr_t e = rbx::Read<uintptr_t>(vec + 8);
            if (b && e && e > b) {
                size_t n = (e - b) / 16;
                for (size_t i = 0; i < n; i++) {
                    uintptr_t c = rbx::Read<uintptr_t>(b + i * 16);
                    if (c) {
                        std::string cname = read_name(c);
                        if (cname == "Players") {
                            InstanceNode p_node;
                            p_node.addr = c;
                            p_node.name = "Players";
                            p_node.cls = "Players";
                            build_tree(p_node, 1, count);
                            g_root.children.push_back(p_node);
                            break;
                        }
                    }
                }
            }
        }

        g_needs_refresh = false;
    }

    // ── Tree Renderer ────────────────────────────────────────────────────

    static bool has_match(InstanceNode& node, const std::string& query) {
        if (query.empty()) return true;

        std::string lname = node.name;
        std::string lcls = node.cls;
        std::transform(lname.begin(), lname.end(), lname.begin(), ::tolower);
        std::transform(lcls.begin(), lcls.end(), lcls.begin(), ::tolower);

        if (lname.find(query) != std::string::npos || lcls.find(query) != std::string::npos)
            return true;

        for (auto& child : node.children) {
            if (has_match(child, query)) return true;
        }
        return false;
    }

    static void draw_node(InstanceNode& node) {
        std::string query = g_search;
        std::transform(query.begin(), query.end(), query.begin(), ::tolower);

        if (!query.empty() && !has_match(node, query)) return;

        bool has_children = !node.children.empty();
        ImGuiTreeNodeFlags flags = ImGuiTreeNodeFlags_OpenOnArrow | ImGuiTreeNodeFlags_OpenOnDoubleClick | ImGuiTreeNodeFlags_SpanAvailWidth;

        if (!has_children) flags |= ImGuiTreeNodeFlags_Leaf;
        if (node.addr == g_selected) flags |= ImGuiTreeNodeFlags_Selected;
        if (!query.empty()) flags |= ImGuiTreeNodeFlags_DefaultOpen;

        ImGui::PushID((void*)node.addr);

        ImVec4 text_color = ImGui::GetStyleColorVec4(ImGuiCol_Text);
        if (node.cls.find("Script") != std::string::npos) text_color = ImVec4(1.0f, 0.7f, 0.2f, 1.0f);
        else if (node.cls.find("Part") != std::string::npos || node.cls.find("Mesh") != std::string::npos) text_color = ImVec4(0.4f, 1.0f, 0.4f, 1.0f);
        else if (node.cls == "Player") text_color = ImVec4(0.4f, 0.8f, 1.0f, 1.0f);

        ImGui::PushStyleColor(ImGuiCol_Text, text_color);

        bool open = ImGui::TreeNodeEx((void*)node.addr, flags, "%s (%s)", node.name.c_str(), node.cls.c_str());

        ImGui::PopStyleColor();

        if (ImGui::IsItemClicked(ImGuiMouseButton_Left) && !ImGui::IsItemToggledOpen()) {
            g_selected = node.addr;
        }

        if (open) {
            for (auto& child : node.children) {
                draw_node(child);
            }
            ImGui::TreePop();
        }
        ImGui::PopID();
    }

    // ── Teleport Logic ───────────────────────────────────────────────────

    static void teleport_to(uintptr_t target_part) {
        if (!target_part) return;

        uintptr_t target_prim = rbx::Read<uintptr_t>(target_part + Offsets::BasePart::Primitive);
        if (!target_prim) return;

        float tx = rbx::Read<float>(target_prim + Offsets::Primitive::Position);
        float ty = rbx::Read<float>(target_prim + Offsets::Primitive::Position + 4);
        float tz = rbx::Read<float>(target_prim + Offsets::Primitive::Position + 8);

        uintptr_t players = 0;
        for (auto& srv : g_root.children) {
            if (srv.name == "Players") { players = srv.addr; break; }
        }
        if (!players) return;

        uintptr_t lp = rbx::Read<uintptr_t>(players + Offsets::Player::LocalPlayer);
        if (!lp) return;

        uintptr_t chr = rbx::Read<uintptr_t>(lp + Offsets::Player::ModelInstance);
        if (!chr) return;

        uintptr_t hum = 0;
        uintptr_t hrp = 0;

        uintptr_t vec = rbx::Read<uintptr_t>(chr + Offsets::Instance::ChildrenStart);
        if (vec) {
            uintptr_t b = rbx::Read<uintptr_t>(vec);
            uintptr_t e = rbx::Read<uintptr_t>(vec + 8);
            if (b && e && e > b) {
                size_t n = (e - b) / 16;
                for (size_t i = 0; i < n; i++) {
                    uintptr_t c = rbx::Read<uintptr_t>(b + i * 16);
                    if (!c) continue;
                    std::string cname = read_name(c);
                    if (cname == "Humanoid") hum = c;
                    else if (cname == "HumanoidRootPart") hrp = c;
                }
            }
        }

        if (!hrp && hum) hrp = rbx::Read<uintptr_t>(hum + Offsets::Humanoid::HumanoidRootPart);
        if (!hrp) return;

        uintptr_t hrp_prim = rbx::Read<uintptr_t>(hrp + Offsets::BasePart::Primitive);
        if (!hrp_prim) return;

        rbx::Write<float>(hrp_prim + Offsets::Primitive::Position, tx);
        rbx::Write<float>(hrp_prim + Offsets::Primitive::Position + 4, ty + 3.0f);
        rbx::Write<float>(hrp_prim + Offsets::Primitive::Position + 8, tz);

        rbx::Write<float>(hrp_prim + Offsets::Primitive::AssemblyLinearVelocity, 0.0f);
        rbx::Write<float>(hrp_prim + Offsets::Primitive::AssemblyLinearVelocity + 4, 0.0f);
        rbx::Write<float>(hrp_prim + Offsets::Primitive::AssemblyLinearVelocity + 8, 0.0f);
    }

    // ── Main UI ──────────────────────────────────────────────────────────

    void Init() {
        g_root = InstanceNode();
    }

    void DrawTab() {
        ImGui::Spacing();
        if (ImGui::Button("Refresh")) g_needs_refresh = true;
        ImGui::SameLine();
        ImGui::Checkbox("Auto Refresh", &g_auto_refresh);

        if (g_auto_refresh) {
            g_refresh_timer += ImGui::GetIO().DeltaTime;
            if (g_refresh_timer > 3.0f) {
                g_needs_refresh = true;
                g_refresh_timer = 0.0f;
            }
        }

        ImGui::SameLine();
        ImGui::SetNextItemWidth(-1);
        ImGui::InputTextWithHint("##search", "Search Workspace...", g_search, sizeof(g_search));

        ImGui::Separator();
        ImGui::Spacing();

        if (g_needs_refresh) {
            Refresh();
        }

        float avail_w = ImGui::GetContentRegionAvail().x;

        // FIX: Very slight indent, tight vertical spacing, and horizontal scrolling enabled
        ImGui::PushStyleVar(ImGuiStyleVar_IndentSpacing, 8.0f);
        ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(2.0f, 2.0f));
        ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(4.0f, 2.0f));

        // Added ImGuiWindowFlags_HorizontalScrollbar
        ImGui::BeginChild("##tree_panel", ImVec2(avail_w * 0.55f, 0), true, ImGuiWindowFlags_HorizontalScrollbar);
        if (g_root.addr != 0) {
            draw_node(g_root);
        }
        else {
            ImGui::TextDisabled("Not attached to DataModel.");
        }
        ImGui::EndChild();

        ImGui::PopStyleVar(3);

        ImGui::SameLine();
        ImGui::BeginChild("##props_panel", ImVec2(0, 0), true);

        if (g_selected != 0) {
            std::string sel_name = read_name(g_selected);
            std::string sel_cls = read_class(g_selected);

            ImGui::TextColored(ImVec4(0.4f, 0.8f, 1.0f, 1.0f), "Properties");
            ImGui::Separator();
            ImGui::Spacing();

            ImGui::TextDisabled("Name:"); ImGui::SameLine(); ImGui::TextWrapped("%s", sel_name.c_str());
            ImGui::TextDisabled("Class:"); ImGui::SameLine(); ImGui::TextWrapped("%s", sel_cls.c_str());
            ImGui::TextDisabled("Address:"); ImGui::SameLine(); ImGui::Text("0x%llX", (unsigned long long)g_selected);

            ImGui::Spacing();
            if (ImGui::Button("Copy Address", ImVec2(-1, 0))) {
                char buf[32];
                snprintf(buf, sizeof(buf), "0x%llX", (unsigned long long)g_selected);
                ImGui::SetClipboardText(buf);
            }

            ImGui::Spacing();
            ImGui::Separator();
            ImGui::Spacing();

            if (sel_cls.find("Part") != std::string::npos || sel_cls == "MeshPart" || sel_cls == "WedgePart") {
                uintptr_t prim = rbx::Read<uintptr_t>(g_selected + Offsets::BasePart::Primitive);
                if (prim && prim > 0x10000) {
                    float x = rbx::Read<float>(prim + Offsets::Primitive::Position);
                    float y = rbx::Read<float>(prim + Offsets::Primitive::Position + 4);
                    float z = rbx::Read<float>(prim + Offsets::Primitive::Position + 8);

                    ImGui::TextDisabled("Position:");
                    ImGui::Text("%.2f, %.2f, %.2f", x, y, z);

                    if (ImGui::Button("Teleport To Part", ImVec2(-1, 0))) {
                        teleport_to(g_selected);
                    }
                }
            }
            else if (sel_cls == "Humanoid") {
                float hp = rbx::Read<float>(g_selected + Offsets::Humanoid::Health);
                float maxhp = rbx::Read<float>(g_selected + Offsets::Humanoid::MaxHealth);
                ImGui::TextDisabled("Health:");
                ImGui::Text("%.1f / %.1f", hp, maxhp);
            }

        }
        else {
            ImGui::TextDisabled("Select an instance to view properties.");
        }

        ImGui::EndChild();
    }

    void Shutdown() {
        g_root = InstanceNode();
    }
}