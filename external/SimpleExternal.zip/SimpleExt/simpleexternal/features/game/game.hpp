#pragma once

namespace game {
    void Init();
    void DrawTab();
    void Shutdown();
}