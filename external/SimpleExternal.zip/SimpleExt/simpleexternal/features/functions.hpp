#pragma once
#include <cstdint>
#include <string>

namespace features {

    // Home tab sliders
    extern float walkspeed;
    extern float jumppower;
    extern float hipheight;

    // Movement
    extern bool  fly_enabled;
    extern float fly_speed;
    extern bool  noclip_enabled;
    extern bool  infinite_jump;

    // World
    extern float camera_fov;
    extern bool  gravity_enabled;
    extern float gravity_value;

    void Start();
    void Stop();
    void Tick();

    bool Attached();
    bool Ready();
    uintptr_t HumanoidAddr();

    uint64_t LocalUserId();
    std::string LocalName();
    std::string PlaceName();
    uint64_t PlaceId();
    std::string ServerId();
}