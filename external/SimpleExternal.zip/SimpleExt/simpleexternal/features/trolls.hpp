#pragma once
#include "imgui.h"

namespace trolls {
    void Init();
    void Tick();
    void DrawTab();
    void Shutdown();
}