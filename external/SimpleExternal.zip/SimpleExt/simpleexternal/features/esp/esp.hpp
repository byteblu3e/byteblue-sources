#pragma once
#include <Windows.h>
#include <string>
#include <vector>
#include <cmath>
#include "imgui.h"
#include "memory.hpp"
#include "offsets.hpp"

namespace esp {

    struct Options {
        bool enabled = false;

        bool  dot = false;
        float dot_color[4] = { 1.0f, 1.0f, 1.0f, 1.0f };
        float dot_size = 3.0f;
        bool  dot_outline = false;
        float dot_outline_color[4] = { 0.0f, 0.0f, 0.0f, 1.0f };

        bool  box = false;
        float box_color[4] = { 1.0f, 1.0f, 1.0f, 1.0f };
        float box_thickness = 1.0f;
        bool  box_outline = false;
        float box_outline_color[4] = { 0.0f, 0.0f, 0.0f, 1.0f };
        bool  box_filled = false;
        float box_fill_color[4] = { 1.0f, 1.0f, 1.0f, 0.15f };

        bool  health = false;
        float health_color[4] = { 0.3f, 0.9f, 0.4f, 1.0f };
        bool  health_gradient = true;
        bool  health_outline = false;
        float health_outline_color[4] = { 0.0f, 0.0f, 0.0f, 1.0f };

        bool  tracer = false;
        float tracer_color[4] = { 1.0f, 1.0f, 1.0f, 1.0f };
        float tracer_thickness = 1.0f;
        bool  tracer_outline = false;
        float tracer_outline_color[4] = { 0.0f, 0.0f, 0.0f, 1.0f };
        int   tracer_origin = 0;

        bool  skeleton = false;
        float skeleton_color[4] = { 1.0f, 1.0f, 1.0f, 1.0f };
        float skeleton_thickness = 1.0f;
        bool  skeleton_outline = false;
        float skeleton_outline_color[4] = { 0.0f, 0.0f, 0.0f, 1.0f };

        // offscreen arrows, edit this ifu hate me
        bool  offscreen = false;
        float offscreen_color[4] = { 1.0f, 0.0f, 0.0f, 1.0f };
        float offscreen_radius = 150.0f;
        float offscreen_size = 15.0f;

        bool  team_check = false;

        float max_dist = 1000.0f;
    };

    struct V3 { float x, y, z; };
    struct V2 { float x, y; };
    struct M3 { float m[9]; };

    Options& Get();
    void Draw(ImDrawList* dl);
    void DrawTab();
}