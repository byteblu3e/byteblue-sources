#include "esp.hpp"
#include "memory.hpp"
#include "offsets.hpp"

#include <Windows.h>
#include <vector>
#include <cmath>
#include <cstdint>
#include <string>

namespace esp {

    static Options g_opts;
    Options& Get() { return g_opts; }

    struct Entry {
        V3 root{}, head{};
        V3 torso{};
        V3 left_arm{}, right_arm{};
        V3 left_leg{}, right_leg{};
        uintptr_t character = 0;
        float hp = 100.0f, maxhp = 100.0f, dist = 0.0f;
        bool is_team = false;
    };

    static std::vector<Entry> g_players;
    static uintptr_t g_dm = 0, g_players_svc = 0, g_lp = 0;
    static DWORD     g_resolve_at = 0;
    static DWORD     g_last_scan = 0;
    static HWND      g_rbx_wnd = nullptr;

    struct Viewport { float x, y, w, h; };

    static BOOL CALLBACK enum_cb(HWND h, LPARAM lp) {
        DWORD pid = 0;
        GetWindowThreadProcessId(h, &pid);
        if (pid != (DWORD)lp) return TRUE;
        if (!IsWindowVisible(h)) return TRUE;
        if (GetWindow(h, GW_OWNER)) return TRUE;
        wchar_t t[64]{};
        GetWindowTextW(h, t, 64);
        if (wcslen(t) == 0) return TRUE;
        g_rbx_wnd = h;
        return FALSE;
    }

    static Viewport get_viewport() {
        Viewport v{ 0, 0,
            (float)GetSystemMetrics(SM_CXSCREEN),
            (float)GetSystemMetrics(SM_CYSCREEN) };
        if (!rbx::g_pid) return v;

        if (!g_rbx_wnd || !IsWindow(g_rbx_wnd)) {
            g_rbx_wnd = nullptr;
            EnumWindows(enum_cb, (LPARAM)rbx::g_pid);
        }
        if (!g_rbx_wnd) return v;

        RECT cr;
        if (!GetClientRect(g_rbx_wnd, &cr)) return v;
        POINT tl{ 0, 0 };
        if (!ClientToScreen(g_rbx_wnd, &tl)) return v;
        v.x = (float)tl.x;
        v.y = (float)tl.y;
        v.w = (float)(cr.right - cr.left);
        v.h = (float)(cr.bottom - cr.top);
        return v;
    }

    static uintptr_t find_child(uintptr_t parent, const char* want) {
        if (!parent) return 0;
        uintptr_t vec = rbx::Read<uintptr_t>(parent + Offsets::Instance::ChildrenStart);
        if (!vec || vec < 0x10000) return 0;
        uintptr_t b = rbx::Read<uintptr_t>(vec);
        uintptr_t e = rbx::Read<uintptr_t>(vec + 8);
        if (!b || !e || e <= b) return 0;
        size_t n = (e - b) / 16;
        if (n == 0 || n > 5000) return 0;
        for (size_t i = 0; i < n; i++) {
            uintptr_t c = rbx::Read<uintptr_t>(b + i * 16);
            if (!c) continue;
            uintptr_t nc = rbx::Read<uintptr_t>(c + Offsets::Instance::NameContainer);
            if (!nc) continue;
            std::string nm = rbx::ReadStr(nc + Offsets::Instance::Name);
            if (nm == want) return c;
        }
        return 0;
    }

    static uintptr_t resolve_dm() {
        if (!rbx::g_base) return 0;
        uintptr_t fdm = rbx::Read<uintptr_t>(rbx::g_base + Offsets::FakeDataModel::Pointer);
        if (!fdm || fdm < 0x10000) return 0;
        uintptr_t dm = rbx::Read<uintptr_t>(fdm + Offsets::FakeDataModel::RealDataModel);
        if (!dm || dm < 0x10000) return 0;
        return dm;
    }

    static V3 read_part_pos(uintptr_t part) {
        if (!part) return {};
        uintptr_t prim = rbx::Read<uintptr_t>(part + Offsets::BasePart::Primitive);
        if (!prim || prim < 0x10000) return {};
        return rbx::Read<V3>(prim + Offsets::Primitive::Position);
    }

    static uintptr_t get_camera() {
        if (!g_dm) return 0;
        uintptr_t ws = rbx::Read<uintptr_t>(g_dm + Offsets::DataModel::Workspace);
        if (!ws) return 0;
        return rbx::Read<uintptr_t>(ws + Offsets::Workspace::CurrentCamera);
    }

    static float read_fov_radians(uintptr_t cam) {
        if (!cam) return 1.22173f;
        float raw = rbx::Read<float>(cam + Offsets::Camera::FieldOfView);
        if (raw > 3.0f) return raw * 3.14159265f / 180.0f;
        if (raw > 0.05f) return raw;
        return 1.22173f;
    }

    static bool w2s(const V3& w, V2& out, const V3& cp, const M3& cr,
        const Viewport& vp, float fov) {
        float rx = w.x - cp.x, ry = w.y - cp.y, rz = w.z - cp.z;

        float r_x = cr.m[0], r_y = cr.m[3], r_z = cr.m[6];
        float u_x = cr.m[1], u_y = cr.m[4], u_z = cr.m[7];
        float b_x = cr.m[2], b_y = cr.m[5], b_z = cr.m[8];

        float x = rx * r_x + ry * r_y + rz * r_z;
        float y = rx * u_x + ry * u_y + rz * u_z;
        float z = -(rx * b_x + ry * b_y + rz * b_z);
        if (z <= 0.01f) return false;

        float aspect = vp.w / vp.h;
        float tan_half = tanf(fov * 0.5f);
        if (tan_half < 0.0001f) return false;

        out.x = vp.x + (vp.w * 0.5f) * (1.0f + x / (z * tan_half * aspect));
        out.y = vp.y + (vp.h * 0.5f) * (1.0f - y / (z * tan_half));

        if (out.x != out.x || out.y != out.y) return false;
        if (fabsf(out.x) > 20000.0f || fabsf(out.y) > 20000.0f) return false;
        return true;
    }

    static ImU32 col4(const float c[4]) {
        return ImGui::ColorConvertFloat4ToU32(ImVec4(c[0], c[1], c[2], c[3]));
    }

    static void draw_offscreen_arrow(ImDrawList* dl, const V3& target_pos, const V3& cam_pos, const M3& cam_rot, const Viewport& vp) {
        Options& o = g_opts;

        float cx = vp.x + vp.w * 0.5f;
        float cy = vp.y + vp.h * 0.5f;

        float dx = target_pos.x - cam_pos.x;
        float dy = target_pos.y - cam_pos.y;
        float dz = target_pos.z - cam_pos.z;

        float r_x = cam_rot.m[0], r_y = cam_rot.m[3], r_z = cam_rot.m[6];
        float u_x = cam_rot.m[1], u_y = cam_rot.m[4], u_z = cam_rot.m[7];
        float b_x = cam_rot.m[2], b_y = cam_rot.m[5], b_z = cam_rot.m[8];

        float x = dx * r_x + dy * r_y + dz * r_z;
        float y = dx * u_x + dy * u_y + dz * u_z;
        float z = -(dx * b_x + dy * b_y + dz * b_z);

        if (z < 0.0f) {
            x = -x;
            y = -y;
        }

        float angle = atan2f(-y, x);

        float rad = o.offscreen_radius;
        float sz = o.offscreen_size;

        float px = cx + cosf(angle) * rad;
        float py = cy + sinf(angle) * rad;

        float fx = cosf(angle);
        float fy = sinf(angle);
        float rx = -sinf(angle);
        float ry = cosf(angle);

        ImVec2 p1 = ImVec2(px + fx * sz, py + fy * sz);
        ImVec2 p2 = ImVec2(px - fx * (sz * 0.5f) + rx * (sz * 0.5f), py - fy * (sz * 0.5f) + ry * (sz * 0.5f));
        ImVec2 p3 = ImVec2(px - fx * (sz * 0.5f) - rx * (sz * 0.5f), py - fy * (sz * 0.5f) - ry * (sz * 0.5f));

        dl->AddTriangleFilled(p1, p2, p3, col4(o.offscreen_color));
    }

    static void draw_dot(ImDrawList* dl, const V2& p) {
        Options& o = g_opts;
        float r = o.dot_size;
        if (o.dot_outline)
            dl->AddCircleFilled(ImVec2(p.x, p.y), r + 1.0f, col4(o.dot_outline_color), 16);
        dl->AddCircleFilled(ImVec2(p.x, p.y), r, col4(o.dot_color), 16);
    }

    static void draw_box(ImDrawList* dl, float x0, float y0, float x1, float y1) {
        Options& o = g_opts;
        if (o.box_filled)
            dl->AddRectFilled(ImVec2(x0, y0), ImVec2(x1, y1), col4(o.box_fill_color));
        if (o.box_outline) {
            ImVec4 oc(o.box_outline_color[0], o.box_outline_color[1],
                o.box_outline_color[2], o.box_outline_color[3] * 0.8f);
            dl->AddRect(ImVec2(x0 - 1.0f, y0 - 1.0f), ImVec2(x1 + 1.0f, y1 + 1.0f),
                ImGui::ColorConvertFloat4ToU32(oc), 0.0f, 0, o.box_thickness + 0.6f);
        }
        dl->AddRect(ImVec2(x0, y0), ImVec2(x1, y1),
            col4(o.box_color), 0.0f, 0, o.box_thickness);
    }

    static void draw_health(ImDrawList* dl, float x0, float y0, float x1, float y1,
        float hp, float maxhp) {
        Options& o = g_opts;
        if (maxhp <= 0.01f) return;
        float frac = hp / maxhp;
        if (frac < 0.0f) frac = 0.0f;
        if (frac > 1.0f) frac = 1.0f;

        const float bar_x1 = std::floor(x0 - 3.0f);
        const float bar_x0 = bar_x1 - 2.0f;

        dl->AddRectFilled(ImVec2(bar_x0, y0), ImVec2(bar_x1, y1), IM_COL32(0, 0, 0, 200));

        float h = y1 - y0;
        float fill_top = y1 - h * frac;
        if (fill_top < y0) fill_top = y0;

        if (frac > 0.001f) {
            if (o.health_gradient) {
                float midY = y0 + h * 0.5f;
                dl->AddRectFilledMultiColor(ImVec2(bar_x0, y0), ImVec2(bar_x1, midY),
                    IM_COL32(255, 0, 0, 255), IM_COL32(255, 0, 0, 255),
                    IM_COL32(255, 255, 0, 255), IM_COL32(255, 255, 0, 255));
                dl->AddRectFilledMultiColor(ImVec2(bar_x0, midY), ImVec2(bar_x1, y1),
                    IM_COL32(255, 255, 0, 255), IM_COL32(255, 255, 0, 255),
                    IM_COL32(0, 255, 0, 255), IM_COL32(0, 255, 0, 255));
                if (fill_top > y0)
                    dl->AddRectFilled(ImVec2(bar_x0, y0), ImVec2(bar_x1, fill_top),
                        IM_COL32(0, 0, 0, 200));
            }
            else {
                dl->AddRectFilled(ImVec2(bar_x0, fill_top), ImVec2(bar_x1, y1),
                    col4(o.health_color));
            }
        }

        if (o.health_outline) {
            ImVec4 ocv(o.health_outline_color[0], o.health_outline_color[1],
                o.health_outline_color[2], o.health_outline_color[3] * 0.8f);
            ImU32 oc = ImGui::ColorConvertFloat4ToU32(ocv);
            dl->AddRectFilled(ImVec2(bar_x0 - 1, y0 - 1), ImVec2(bar_x1 + 1, y0), oc);
            dl->AddRectFilled(ImVec2(bar_x0 - 1, y1), ImVec2(bar_x1 + 1, y1 + 1), oc);
            dl->AddRectFilled(ImVec2(bar_x0 - 1, y0), ImVec2(bar_x0, y1), oc);
            dl->AddRectFilled(ImVec2(bar_x1, y0), ImVec2(bar_x1 + 1, y1), oc);
        }
    }

    static void draw_tracer(ImDrawList* dl, float tx, float ty, const Viewport& vp) {
        Options& o = g_opts;
        float sx = vp.x + vp.w * 0.5f;
        float sy = vp.y + vp.h;
        if (o.tracer_origin == 1) sy = vp.y;
        else if (o.tracer_origin == 2) sy = vp.y + vp.h * 0.5f;
        if (o.tracer_outline) {
            ImVec4 ocv(o.tracer_outline_color[0], o.tracer_outline_color[1],
                o.tracer_outline_color[2], o.tracer_outline_color[3] * 0.8f);
            dl->AddLine(ImVec2(sx, sy), ImVec2(tx, ty),
                ImGui::ColorConvertFloat4ToU32(ocv), o.tracer_thickness + 0.6f);
        }
        dl->AddLine(ImVec2(sx, sy), ImVec2(tx, ty),
            col4(o.tracer_color), o.tracer_thickness);
    }

    static void bone(ImDrawList* dl, const V3& a, const V3& b,
        const V3& cp, const M3& cr, const Viewport& vp, float fov) {
        Options& o = g_opts;
        if (a.x == 0 && a.y == 0 && a.z == 0) return;
        if (b.x == 0 && b.y == 0 && b.z == 0) return;
        V2 sa{}, sb{};
        if (!w2s(a, sa, cp, cr, vp, fov)) return;
        if (!w2s(b, sb, cp, cr, vp, fov)) return;
        if (o.skeleton_outline) {
            ImVec4 ocv(o.skeleton_outline_color[0], o.skeleton_outline_color[1],
                o.skeleton_outline_color[2], o.skeleton_outline_color[3] * 0.8f);
            dl->AddLine(ImVec2(sa.x, sa.y), ImVec2(sb.x, sb.y),
                ImGui::ColorConvertFloat4ToU32(ocv), o.skeleton_thickness + 0.6f);
        }
        dl->AddLine(ImVec2(sa.x, sa.y), ImVec2(sb.x, sb.y),
            col4(o.skeleton_color), o.skeleton_thickness);
    }

    static void draw_skeleton(ImDrawList* dl, const Entry& e,
        const V3& cp, const M3& cr, const Viewport& vp, float fov) {
        bone(dl, e.torso, e.head, cp, cr, vp, fov);
        bone(dl, e.torso, e.left_arm, cp, cr, vp, fov);
        bone(dl, e.torso, e.right_arm, cp, cr, vp, fov);
        bone(dl, e.torso, e.left_leg, cp, cr, vp, fov);
        bone(dl, e.torso, e.right_leg, cp, cr, vp, fov);
    }

    // ── scan ───────────────────────────────────────────────────────────

    static void scan_players() {
        DWORD now_frame = GetTickCount();
        if (now_frame - g_last_scan < 30 && !g_players.empty()) return;
        g_last_scan = now_frame;

        g_players.clear();
        if (!rbx::g_base) return;

        DWORD now = GetTickCount();
        if (now - g_resolve_at > 800 || !g_dm) {
            g_resolve_at = now;
            g_dm = resolve_dm();
            g_players_svc = 0;
            g_lp = 0;
            if (g_dm) {
                g_players_svc = find_child(g_dm, "Players");
                if (g_players_svc)
                    g_lp = rbx::Read<uintptr_t>(g_players_svc + Offsets::Player::LocalPlayer);
            }
        }
        if (!g_players_svc || !g_lp) return;

        uintptr_t my_char = rbx::Read<uintptr_t>(g_lp + Offsets::Player::ModelInstance);
        uintptr_t cam = get_camera();
        V3 cam_pos{};
        if (cam) cam_pos = rbx::Read<V3>(cam + Offsets::Camera::Position);
        uintptr_t my_team = rbx::Read<uintptr_t>(g_lp + Offsets::Player::Team);

        uintptr_t vec = rbx::Read<uintptr_t>(g_players_svc + Offsets::Instance::ChildrenStart);
        if (!vec) return;
        uintptr_t b = rbx::Read<uintptr_t>(vec);
        uintptr_t e = rbx::Read<uintptr_t>(vec + 8);
        if (!b || !e || e <= b) return;
        size_t n = (e - b) / 16;
        if (n == 0 || n > 200) return;

        for (size_t i = 0; i < n; i++) {
            uintptr_t p = rbx::Read<uintptr_t>(b + i * 16);
            if (!p || p == g_lp) continue;

            uintptr_t ch = rbx::Read<uintptr_t>(p + Offsets::Player::ModelInstance);
            if (!ch || ch == my_char) continue;

            uintptr_t hum = find_child(ch, "Humanoid");
            if (!hum) continue;

            float hp = rbx::Read<float>(hum + Offsets::Humanoid::Health);
            float mx = rbx::Read<float>(hum + Offsets::Humanoid::MaxHealth);
            if (!(hp > 0.0f) || hp > 100000.0f) continue;
            if (!(mx > 0.0f) || mx > 100000.0f) mx = 100.0f;

            uintptr_t hrp = rbx::Read<uintptr_t>(hum + Offsets::Humanoid::HumanoidRootPart);
            if (!hrp) hrp = find_child(ch, "HumanoidRootPart");

            Entry ent{};
            ent.character = ch;
            ent.root = read_part_pos(hrp);
            if (ent.root.x == 0.0f && ent.root.y == 0.0f && ent.root.z == 0.0f) continue;

            ent.head = read_part_pos(find_child(ch, "Head"));
            if (ent.head.x == 0.0f && ent.head.y == 0.0f && ent.head.z == 0.0f)
                ent.head = V3{ ent.root.x, ent.root.y + 2.5f, ent.root.z };

            ent.torso = read_part_pos(find_child(ch, "UpperTorso"));
            if (ent.torso.x == 0.0f) ent.torso = read_part_pos(find_child(ch, "Torso"));
            if (ent.torso.x == 0.0f) ent.torso = ent.root;

            ent.left_arm = read_part_pos(find_child(ch, "LeftUpperArm"));
            if (ent.left_arm.x == 0.0f) ent.left_arm = read_part_pos(find_child(ch, "Left Arm"));
            ent.right_arm = read_part_pos(find_child(ch, "RightUpperArm"));
            if (ent.right_arm.x == 0.0f) ent.right_arm = read_part_pos(find_child(ch, "Right Arm"));
            ent.left_leg = read_part_pos(find_child(ch, "LeftUpperLeg"));
            if (ent.left_leg.x == 0.0f) ent.left_leg = read_part_pos(find_child(ch, "Left Leg"));
            ent.right_leg = read_part_pos(find_child(ch, "RightUpperLeg"));
            if (ent.right_leg.x == 0.0f) ent.right_leg = read_part_pos(find_child(ch, "Right Leg"));

            uintptr_t their_team = rbx::Read<uintptr_t>(p + Offsets::Player::Team);
            ent.is_team = (my_team != 0 && their_team != 0 && their_team == my_team);

            ent.hp = hp; ent.maxhp = mx;

            if (cam_pos.x != 0.0f || cam_pos.y != 0.0f || cam_pos.z != 0.0f) {
                float dx = ent.root.x - cam_pos.x;
                float dy = ent.root.y - cam_pos.y;
                float dz = ent.root.z - cam_pos.z;
                ent.dist = sqrtf(dx * dx + dy * dy + dz * dz);
                if (ent.dist > g_opts.max_dist) continue;
            }
            g_players.push_back(ent);
        }
    }

    // ── main draw ──────────────────────────────────────────────────────

    void Draw(ImDrawList* dl) {
        if (!dl || !rbx::g_base || !rbx::alive()) return;
        if (!g_opts.enabled) return;

        scan_players();
        if (g_players.empty()) return;

        bool any_draw =
            (g_opts.dot || g_opts.box || g_opts.health ||
                g_opts.tracer || g_opts.skeleton || g_opts.offscreen);
        if (!any_draw) return;

        uintptr_t cam = get_camera();
        if (!cam) return;
        V3 cam_pos = rbx::Read<V3>(cam + Offsets::Camera::Position);
        M3 cam_rot = rbx::Read<M3>(cam + Offsets::Camera::Rotation);
        float fov = read_fov_radians(cam);
        if (cam_pos.x == 0.0f && cam_pos.y == 0.0f && cam_pos.z == 0.0f) return;

        Viewport vp = get_viewport();
        if (vp.w < 100.0f || vp.h < 100.0f) return;

        dl->PushClipRect(ImVec2(vp.x, vp.y), ImVec2(vp.x + vp.w, vp.y + vp.h), true);

        for (auto& e : g_players) {
            if (g_opts.team_check && e.is_team) continue;

            V3 top3 = e.head; top3.y += 0.5f;
            V3 bot3 = e.root; bot3.y -= 2.5f;

            V2 top{}, bot{}, hdp{};
            bool on_screen = w2s(top3, top, cam_pos, cam_rot, vp, fov) &&
                (top.x >= vp.x && top.x <= vp.x + vp.w &&
                    top.y >= vp.y && top.y <= vp.y + vp.h);

            if (!on_screen) {
                if (g_opts.offscreen)
                    draw_offscreen_arrow(dl, e.head, cam_pos, cam_rot, vp);
                continue;
            }

            if (!w2s(bot3, bot, cam_pos, cam_rot, vp, fov)) continue;

            float h = bot.y - top.y;
            if (h < 4.0f || h > 3000.0f) continue;
            float w = h * 0.55f;
            float x0 = top.x - w * 0.5f, y0 = top.y;
            float x1 = x0 + w, y1 = y0 + h;

            if (g_opts.box)
                draw_box(dl, std::floor(x0), std::floor(y0),
                    std::floor(x1), std::floor(y1));

            if (g_opts.health)
                draw_health(dl, x0, y0, x1, y1, e.hp, e.maxhp);

            if (g_opts.tracer)
                draw_tracer(dl, (x0 + x1) * 0.5f, y1, vp);

            if (g_opts.skeleton)
                draw_skeleton(dl, e, cam_pos, cam_rot, vp, fov);

            if (g_opts.dot) {
                if (w2s(e.head, hdp, cam_pos, cam_rot, vp, fov))
                    draw_dot(dl, hdp);
            }
        }

        dl->PopClipRect();
    }

    // ── ui (plain, default ImGui widgets) ──────────────────────────────

    void DrawTab() {
        Options& o = g_opts;
        ImGui::BeginChild("##esp_scroll", ImVec2(0, 0), false);

        ImGui::TextUnformatted("ESP");
        ImGui::Separator();
        ImGui::Checkbox("Enable ESP", &o.enabled);
        ImGui::BeginDisabled(!o.enabled);

        ImGui::TextUnformatted("Max Distance");
        ImGui::SetNextItemWidth(-1);
        ImGui::SliderFloat("##esp_maxd", &o.max_dist, 50.0f, 5000.0f, "%.0f");

        ImGui::Checkbox("Team Check", &o.team_check);

        ImGui::Spacing();
        ImGui::TextUnformatted("Offscreen Arrows");
        ImGui::Separator();
        ImGui::Checkbox("Enable Arrows", &o.offscreen);
        if (o.offscreen) {
            ImGui::ColorEdit4("Color##off_col", o.offscreen_color, ImGuiColorEditFlags_AlphaBar);
            ImGui::SliderFloat("Radius##off_rad", &o.offscreen_radius, 50.0f, 500.0f, "%.0f");
            ImGui::SliderFloat("Size##off_sz", &o.offscreen_size, 5.0f, 50.0f, "%.1f");
        }

        ImGui::Spacing();
        ImGui::TextUnformatted("Dot");
        ImGui::Separator();
        ImGui::Checkbox("Head Dot", &o.dot);
        if (o.dot) {
            ImGui::SliderFloat("Size##dot_size", &o.dot_size, 1.0f, 12.0f, "%.1f");
            ImGui::ColorEdit4("Color##dot_col", o.dot_color,
                ImGuiColorEditFlags_AlphaBar);
            ImGui::Checkbox("Outline##dot", &o.dot_outline);
            if (o.dot_outline)
                ImGui::ColorEdit4("Color##dot_ocol", o.dot_outline_color,
                    ImGuiColorEditFlags_AlphaBar);
        }

        ImGui::Spacing();
        ImGui::TextUnformatted("Box");
        ImGui::Separator();
        ImGui::Checkbox("Box", &o.box);
        if (o.box) {
            ImGui::SliderFloat("Thickness##box_thick", &o.box_thickness, 0.5f, 5.0f, "%.1f");
            ImGui::ColorEdit4("Color##box_col", o.box_color,
                ImGuiColorEditFlags_AlphaBar);
            ImGui::Checkbox("Filled##box", &o.box_filled);
            if (o.box_filled)
                ImGui::ColorEdit4("Fill Color##box_fill", o.box_fill_color,
                    ImGuiColorEditFlags_AlphaBar);
            ImGui::Checkbox("Outline##box", &o.box_outline);
            if (o.box_outline)
                ImGui::ColorEdit4("Outline Color##box_ocol", o.box_outline_color,
                    ImGuiColorEditFlags_AlphaBar);
        }

        ImGui::Spacing();
        ImGui::TextUnformatted("Skeleton");
        ImGui::Separator();
        ImGui::Checkbox("Skeleton", &o.skeleton);
        if (o.skeleton) {
            ImGui::SliderFloat("Thickness##sk_thick", &o.skeleton_thickness, 0.5f, 4.0f, "%.1f");
            ImGui::ColorEdit4("Color##sk_col", o.skeleton_color,
                ImGuiColorEditFlags_AlphaBar);
            ImGui::Checkbox("Outline##sk", &o.skeleton_outline);
            if (o.skeleton_outline)
                ImGui::ColorEdit4("Outline Color##sk_ocol", o.skeleton_outline_color,
                    ImGuiColorEditFlags_AlphaBar);
        }

        ImGui::Spacing();
        ImGui::TextUnformatted("Health");
        ImGui::Separator();
        ImGui::Checkbox("Health Bar", &o.health);
        if (o.health) {
            ImGui::Checkbox("Gradient##hp", &o.health_gradient);
            if (!o.health_gradient)
                ImGui::ColorEdit4("Color##hp_col", o.health_color,
                    ImGuiColorEditFlags_AlphaBar);
            ImGui::Checkbox("Outline##hp", &o.health_outline);
            if (o.health_outline)
                ImGui::ColorEdit4("Outline Color##hp_ocol", o.health_outline_color,
                    ImGuiColorEditFlags_AlphaBar);
        }

        ImGui::Spacing();
        ImGui::TextUnformatted("Tracer");
        ImGui::Separator();
        ImGui::Checkbox("Tracer", &o.tracer);
        if (o.tracer) {
            ImGui::SliderFloat("Thickness##tr_thick", &o.tracer_thickness, 0.5f, 5.0f, "%.1f");
            const char* origins[] = { "Bottom", "Top", "Center" };
            ImGui::Combo("Origin##tr_org", &o.tracer_origin, origins, IM_ARRAYSIZE(origins));
            ImGui::ColorEdit4("Color##tr_col", o.tracer_color,
                ImGuiColorEditFlags_AlphaBar);
            ImGui::Checkbox("Outline##tr", &o.tracer_outline);
            if (o.tracer_outline)
                ImGui::ColorEdit4("Outline Color##tr_ocol", o.tracer_outline_color,
                    ImGuiColorEditFlags_AlphaBar);
        }

        ImGui::EndDisabled();
        ImGui::EndChild();
    }
}