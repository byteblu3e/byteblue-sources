#pragma once
#include <string>
#include <unordered_map>

namespace aim {
    void Init();
    void Shutdown();
    void DrawTab();
    void DrawOverlay();

    void SaveConfig(std::unordered_map<std::string, std::string>& m);
    void LoadConfig(const std::unordered_map<std::string, std::string>& m);

    void ApplyAfterLoad();
}