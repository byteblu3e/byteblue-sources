#include "aim.hpp"
#include "esp.hpp" 
#include "memory.hpp"
#include "offsets.hpp"

#include <Windows.h>
#include <mmsystem.h>
#include <thread>
#include <chrono>
#include <atomic>
#include <cmath>
#include <cstdint>
#include <string>
#include <vector>
#include <algorithm>
#include <random>
#include <unordered_map>

#pragma comment(lib, "winmm.lib")

namespace aim {

    using V3 = esp::V3;
    using M3 = esp::M3;

    enum AimMode { MODE_CROSSHAIR = 0, MODE_NEAREST, MODE_FARTHEST, MODE_RANDOM };
    enum Hitbox { HB_HEAD = 0, HB_UPPER_TORSO, HB_TORSO, HB_LOWER_TORSO, HB_RANDOM };
    enum SmoothMode { SM_SPEED = 0, SM_FIXED, SM_LINEAR, SM_EASEOUT, SM_EASEINOUT, SM_CUBIC, SM_VELOCITY };
    enum AimMethod { METHOD_MATRIX = 0, METHOD_MOUSE, METHOD_LEGACY, METHOD_BOTH, METHOD_ALL };

    static constexpr int CAM_CUSTOM = 5;
    static constexpr int CAM_SCRIPTABLE = 6;
    static constexpr float PI_F = 3.14159265f;
    static constexpr float RAD2DEG = 57.2957795f;
    static constexpr float DEG2RAD = 0.01745329252f;
    static constexpr float MAX_TICK_DT = 0.020f;
    static constexpr int MIN_WRITE_SPRAY = 3;

    static bool  s_enabled = false;
    static bool  s_lmb = true;
    static bool  s_rmb = false;
    static bool  s_dead = true;
    static bool  s_draw_fov = false;
    static bool  s_autofire = false;
    static bool  s_sticky = true;
    static bool  s_team_check = false;
    static bool  s_force_scriptable = true;
    static bool  s_restore_cam_type = true;

    static bool  s_trig_bot = false;
    static int   s_trig_delay = 80;
    static float s_trig_radius_deg = 2.0f;

    static int   s_aim_method = METHOD_MATRIX;
    static float s_mouse_scale = 1.00f;
    static float s_mouse_max_px = 500.0f;
    static int   s_mouse_rate_ms = 1;
    static float s_mouse_deadband_deg = 0.04f;

    static bool  s_smooth = false;
    static int   s_smooth_mode = SM_SPEED;
    static float s_aim_speed_dps = 4500.0f;
    static float s_smooth_fixed_k = 0.35f;
    static float s_smooth_ms = 60.0f;
    static float s_smooth_tau = 0.035f;
    static float s_smooth_max_accel = 40000.0f;
    static int   s_autofire_delay = 80;

    static int   s_pick_cache_ms = 30;
    static bool  s_disable_focus_check = false;
    static bool  s_close_range_engage = true;
    static float s_close_range = 6.0f;

    static char  s_ignore_buf[512] = "";
    static std::vector<std::string> s_ignore_names;

    static int   s_mode = MODE_CROSSHAIR;
    static int   s_hitbox = HB_HEAD;
    static int   s_aim_key = 0;
    static float s_fov = 90.0f;
    static float s_max_dist = 1000.0f;

    static float s_fov_color[4] = { 0.35f, 0.82f, 0.43f, 0.67f };
    static float s_fov_thick = 1.6f;
    static bool  s_fov_anim = true;

    static bool  s_hum_enabled = false;
    static float s_hum_strength = 1.00f;
    static bool  s_hum_jitter = true;
    static float s_hum_jitter_deg = 0.35f;
    static float s_hum_jitter_hz = 3.0f;
    static bool  s_hum_reaction = true;
    static int   s_hum_reaction_ms = 120;
    static bool  s_hum_overshoot = true;
    static float s_hum_overshoot_chance = 0.20f;
    static float s_hum_overshoot_deg = 2.50f;
    static int   s_hum_overshoot_ms = 80;
    static bool  s_hum_micro = true;
    static float s_hum_micro_px = 1.20f;

    static std::thread g_worker;
    static std::atomic<bool> g_run{ false };
    static uintptr_t g_dm = 0, g_players_svc = 0, g_lp = 0;
    static DWORD g_resolve_at = 0;
    static int s_cam_type_saved = 0;
    static bool s_cam_forced = false;

    struct AimTarget {
        uintptr_t entry = 0;
        uintptr_t character = 0;
        V3 eye_pos{};
        float distance = 0.0f;
        float angle_deg = 0.0f;
        bool is_team = false;
    };

    struct HumState {
        uintptr_t last_target = 0;
        DWORD     acquired_ms = 0;
        float     over_yaw = 0.0f;
        float     over_pitch = 0.0f;
        DWORD     over_until = 0;
        float     phase_a = 0.0f, phase_b = 0.0f, phase_c = 0.0f;
        DWORD     last_micro_ms = 0;
        bool      inited = false;
    };
    static HumState s_hum{};
    static std::mt19937 s_rng{ std::random_device{}() };

    static LARGE_INTEGER s_qpc_freq{};
    static LARGE_INTEGER s_qpc_prev{};
    static bool s_qpc_init = false;

    static uintptr_t find_child(uintptr_t parent, const char* want) {
        uintptr_t vec = rbx::Read<uintptr_t>(parent + Offsets::Instance::ChildrenStart);
        if (!vec) return 0;
        uintptr_t b = rbx::Read<uintptr_t>(vec);
        uintptr_t e = rbx::Read<uintptr_t>(vec + 8);
        if (!b || !e || e <= b) return 0;
        for (size_t i = 0; i < (e - b) / 16; i++) {
            uintptr_t c = rbx::Read<uintptr_t>(b + i * 16);
            if (c && rbx::ReadStr(rbx::Read<uintptr_t>(c + Offsets::Instance::NameContainer) + Offsets::Instance::Name) == want) return c;
        }
        return 0;
    }

    static uintptr_t resolve_dm() {
        if (!rbx::g_base) return 0;
        uintptr_t fdm = rbx::Read<uintptr_t>(rbx::g_base + Offsets::FakeDataModel::Pointer);
        if (!fdm) return 0;
        return rbx::Read<uintptr_t>(fdm + Offsets::FakeDataModel::RealDataModel);
    }

    static uintptr_t get_camera() {
        uintptr_t ws = rbx::Read<uintptr_t>(g_dm + Offsets::DataModel::Workspace);
        return ws ? rbx::Read<uintptr_t>(ws + Offsets::Workspace::CurrentCamera) : 0;
    }

    static V3 read_part_pos(uintptr_t part) {
        if (!part) return {};
        uintptr_t prim = rbx::Read<uintptr_t>(part + Offsets::BasePart::Primitive);
        return prim ? rbx::Read<V3>(prim + Offsets::Primitive::Position) : V3{};
    }

    static bool key_down() {
        switch (s_aim_key) {
        case 0: return true;
        case 1: return (GetAsyncKeyState(VK_LBUTTON) & 0x8000) != 0;
        case 2: return (GetAsyncKeyState(VK_RBUTTON) & 0x8000) != 0;
        case 3: return (GetAsyncKeyState(VK_MBUTTON) & 0x8000) != 0;
        case 4: return (GetAsyncKeyState(VK_SHIFT) & 0x8000) != 0;
        case 5: return (GetAsyncKeyState(VK_MENU) & 0x8000) != 0;
        case 6: return (GetAsyncKeyState(VK_CONTROL) & 0x8000) != 0;
        case 7: return (GetAsyncKeyState('E') & 0x8000) != 0;
        case 8: return (GetAsyncKeyState('Q') & 0x8000) != 0;
        case 9: return (GetAsyncKeyState('X') & 0x8000) != 0;
        case 10: return (GetAsyncKeyState('Z') & 0x8000) != 0;
        case 11: return (GetAsyncKeyState('F') & 0x8000) != 0;
        case 12: return (GetAsyncKeyState('V') & 0x8000) != 0;
        case 13: return (GetAsyncKeyState('C') & 0x8000) != 0;
        case 14: return (GetAsyncKeyState(VK_CAPITAL) & 0x8000) != 0;
        case 15: return (GetAsyncKeyState(VK_XBUTTON1) & 0x8000) != 0;
        case 16: return (GetAsyncKeyState(VK_XBUTTON2) & 0x8000) != 0;
        default: return true;
        }
    }

    static void look_from_fwd(const V3& fwd, M3& out) {
        const V3 up{ 0, 1, 0 };
        V3 right{ fwd.y * up.z - fwd.z * up.y, fwd.z * up.x - fwd.x * up.z, fwd.x * up.y - fwd.y * up.x };
        float rl = sqrtf(right.x * right.x + right.y * right.y + right.z * right.z);

        if (rl < 0.001f) {
            right = { 1, 0, 0 };
            rl = 1;
        }

        right.x /= rl; right.y /= rl; right.z /= rl;
        V3 u{ right.y * fwd.z - right.z * fwd.y, right.z * fwd.x - right.x * fwd.z, right.x * fwd.y - right.y * fwd.x };

        out.m[0] = right.x; out.m[1] = u.x; out.m[2] = -fwd.x;
        out.m[3] = right.y; out.m[4] = u.y; out.m[5] = -fwd.y;
        out.m[6] = right.z; out.m[7] = u.z; out.m[8] = -fwd.z;
    }

    static bool pick_target(AimTarget& out) {
        uintptr_t cam = get_camera();
        if (!cam) return false;

        V3 cam_pos = rbx::Read<V3>(cam + Offsets::Camera::Position);
        M3 cam_rot = rbx::Read<M3>(cam + Offsets::Camera::Rotation);
        if (cam_pos.x == 0.0f && cam_pos.y == 0.0f && cam_pos.z == 0.0f) return false;

        V3 fwd = { -cam_rot.m[2], -cam_rot.m[5], -cam_rot.m[8] };
        float fl = sqrtf(fwd.x * fwd.x + fwd.y * fwd.y + fwd.z * fwd.z);
        if (fl < 0.001f) return false;
        fwd.x /= fl; fwd.y /= fl; fwd.z /= fl;

        uintptr_t my_char = rbx::Read<uintptr_t>(g_lp + Offsets::Player::ModelInstance);
        uintptr_t my_team = rbx::Read<uintptr_t>(g_lp + Offsets::Player::Team);

        uintptr_t vec = rbx::Read<uintptr_t>(g_players_svc + Offsets::Instance::ChildrenStart);
        if (!vec) return false;
        uintptr_t b = rbx::Read<uintptr_t>(vec);
        uintptr_t e = rbx::Read<uintptr_t>(vec + 8);
        if (!b || !e || e <= b) return false;
        size_t n = (e - b) / 16;
        if (n == 0 || n > 200) return false;

        float best_angle = s_fov;
        AimTarget best{};
        bool found = false;

        for (size_t i = 0; i < n; i++) {
            uintptr_t p = rbx::Read<uintptr_t>(b + i * 16);
            if (!p || p == g_lp) continue;

            if (s_team_check && my_team != 0) {
                uintptr_t their_team = rbx::Read<uintptr_t>(p + Offsets::Player::Team);
                if (their_team != 0 && their_team == my_team) continue;
            }

            uintptr_t ch = rbx::Read<uintptr_t>(p + Offsets::Player::ModelInstance);
            if (!ch || ch == my_char) continue;

            uintptr_t hum = find_child(ch, "Humanoid");
            if (!hum) continue;

            float hp = rbx::Read<float>(hum + Offsets::Humanoid::Health);
            if (!(hp > 0.0f)) continue;

            uintptr_t hrp = rbx::Read<uintptr_t>(hum + Offsets::Humanoid::HumanoidRootPart);
            if (!hrp) hrp = find_child(ch, "HumanoidRootPart");

            V3 tgt = read_part_pos(hrp);
            if (tgt.x == 0.0f && tgt.y == 0.0f && tgt.z == 0.0f) continue;

            V3 aim_pt{ tgt.x, tgt.y + 1.0f, tgt.z };

            float dx = aim_pt.x - cam_pos.x;
            float dy = aim_pt.y - cam_pos.y;
            float dz = aim_pt.z - cam_pos.z;
            float dist = sqrtf(dx * dx + dy * dy + dz * dz);

            if (dist < 0.5f || dist > s_max_dist) continue;

            float nx = dx / dist, ny = dy / dist, nz = dz / dist;
            float dot = fwd.x * nx + fwd.y * ny + fwd.z * nz;

            if (dot > 1.0f) dot = 1.0f;
            if (dot < -1.0f) dot = -1.0f;
            float angle = acosf(dot) * RAD2DEG;

            if (angle < best_angle) {
                best_angle = angle;
                best.entry = p;
                best.character = ch;
                best.eye_pos = aim_pt;
                best.distance = dist;
                best.angle_deg = angle;
                found = true;
            }
        }

        if (found) out = best;
        return found;
    }

    static void hum_init_once() {
        if (s_hum.inited) return;
        s_hum.inited = true;
        std::uniform_real_distribution<float> d(0.0f, 6.28318f);
        s_hum.phase_a = d(s_rng);
        s_hum.phase_b = d(s_rng);
        s_hum.phase_c = d(s_rng);
    }

    static void hum_on_target(uintptr_t addr) {
        hum_init_once();
        if (addr == s_hum.last_target) return;

        s_hum.last_target = addr;
        DWORD now = GetTickCount();
        s_hum.acquired_ms = now;
        s_hum.over_until = 0;
        s_hum.over_yaw = 0.0f;
        s_hum.over_pitch = 0.0f;

        if (s_hum_overshoot && addr != 0) {
            std::uniform_real_distribution<float> u(0.0f, 1.0f);
            if (u(s_rng) < s_hum_overshoot_chance) {
                std::uniform_real_distribution<float> a(-s_hum_overshoot_deg, s_hum_overshoot_deg);
                s_hum.over_yaw = a(s_rng) * s_hum_strength;
                s_hum.over_pitch = a(s_rng) * s_hum_strength;
                s_hum.over_until = now + (DWORD)(s_hum_overshoot_ms < 1 ? 1 : s_hum_overshoot_ms);
            }
        }
    }

    static bool hum_in_reaction() {
        if (!s_hum_enabled || !s_hum_reaction) return false;
        if (s_hum_reaction_ms <= 0) return false;
        return (GetTickCount() - s_hum.acquired_ms) < (DWORD)s_hum_reaction_ms;
    }

    static void hum_offsets(float& out_yaw, float& out_pitch) {
        out_yaw = 0.0f;
        out_pitch = 0.0f;
        if (!s_hum_enabled) return;

        hum_init_once();
        DWORD now = GetTickCount();
        float t = (float)now * 0.001f;

        if (s_hum_jitter) {
            float amp = s_hum_jitter_deg * s_hum_strength;
            float w = s_hum_jitter_hz * 6.28318f;

            out_yaw = sinf(t * w + s_hum.phase_a) * amp
                + sinf(t * w * 1.7f + s_hum.phase_b) * amp * 0.40f
                + sinf(t * w * 0.53f + s_hum.phase_c) * amp * 0.25f;

            out_pitch = cosf(t * w * 1.3f + s_hum.phase_c) * amp * 0.85f
                + sinf(t * w * 0.71f + s_hum.phase_a) * amp * 0.30f;
        }

        if (s_hum_overshoot && s_hum.over_until > now && s_hum_overshoot_ms > 0) {
            float rem = (float)(s_hum.over_until - now) / (float)s_hum_overshoot_ms;
            if (rem < 0.0f) rem = 0.0f;
            if (rem > 1.0f) rem = 1.0f;

            out_yaw += s_hum.over_yaw * rem;
            out_pitch += s_hum.over_pitch * rem;
        }
    }

    static void hum_micro_mouse() {
        if (!s_hum_enabled || !s_hum_micro) return;
        hum_init_once();

        DWORD now = GetTickCount();
        if (now - s_hum.last_micro_ms < 28) return;
        s_hum.last_micro_ms = now;

        std::uniform_real_distribution<float> d(-s_hum_micro_px, s_hum_micro_px);
        float dx = d(s_rng) * s_hum_strength;
        float dy = d(s_rng) * s_hum_strength;

        if (fabsf(dx) < 0.25f && fabsf(dy) < 0.25f) return;

        INPUT in{};
        in.type = INPUT_MOUSE;
        in.mi.dx = (LONG)roundf(dx);
        in.mi.dy = (LONG)roundf(dy);
        in.mi.dwFlags = MOUSEEVENTF_MOVE;
        SendInput(1, &in, sizeof(INPUT));
    }

    static void worker() {
        timeBeginPeriod(1);
        SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_HIGHEST);

        while (g_run.load()) {
            Sleep(4);
            if (!rbx::alive() || !s_enabled || !key_down()) continue;

            DWORD now = GetTickCount();
            if (now - g_resolve_at > 800 || !g_dm) {
                g_resolve_at = now;
                g_dm = resolve_dm();
                g_players_svc = g_dm ? find_child(g_dm, "Players") : 0;
                g_lp = g_players_svc ? rbx::Read<uintptr_t>(g_players_svc + Offsets::Player::LocalPlayer) : 0;
            }
            if (!g_players_svc || !g_lp) continue;

            AimTarget target;
            if (!pick_target(target)) continue;

            uintptr_t cam = get_camera();
            if (!cam) continue;

            // Force CameraType to Scriptable so we can override it
            rbx::Write<int>(cam + Offsets::Camera::CameraType, CAM_SCRIPTABLE);

            V3 cam_pos = rbx::Read<V3>(cam + Offsets::Camera::Position);
            V3 delta = { target.eye_pos.x - cam_pos.x, target.eye_pos.y - cam_pos.y, target.eye_pos.z - cam_pos.z };
            float len = sqrtf(delta.x * delta.x + delta.y * delta.y + delta.z * delta.z);
            if (len < 0.01f) continue;

            V3 fwd = { delta.x / len, delta.y / len, delta.z / len };
            V3 final_fwd = fwd;

            if (s_smooth) {
                M3 cur = rbx::Read<M3>(cam + Offsets::Camera::Rotation);
                V3 cur_fwd = { -cur.m[2], -cur.m[5], -cur.m[8] };

                float s = s_aim_speed_dps;
                if (s < 1.0f) s = 1.0f;
                float t = 1.0f / s;

                V3 blended{
                    cur_fwd.x + (fwd.x - cur_fwd.x) * t,
                    cur_fwd.y + (fwd.y - cur_fwd.y) * t,
                    cur_fwd.z + (fwd.z - cur_fwd.z) * t
                };

                float bl = sqrtf(blended.x * blended.x + blended.y * blended.y + blended.z * blended.z);
                if (bl > 0.001f) final_fwd = { blended.x / bl, blended.y / bl, blended.z / bl };
            }

            M3 out{};
            look_from_fwd(final_fwd, out);

            // Spray write multiple times to ensure it sticks
            for (int i = 0; i < MIN_WRITE_SPRAY; i++) {
                rbx::Write<M3>(cam + Offsets::Camera::Rotation, out);
            }
        }
        timeEndPeriod(1);
    }

    void Init() {
        if (g_run.exchange(true)) return;
        g_worker = std::thread(worker);
    }

    void Shutdown() {
        if (!g_run.exchange(false)) return;
        if (g_worker.joinable()) g_worker.join();
    }

    void DrawOverlay() {
        if (!s_enabled || !s_draw_fov) return;
        ImDrawList* dl = ImGui::GetForegroundDrawList();
        POINT p;
        if (!GetCursorPos(&p)) return;

        float screen_h = (float)GetSystemMetrics(SM_CYSCREEN);
        float half = s_fov * 0.5f;
        float radius = tanf(half * 3.14159265f / 180.0f) / tanf(35.0f * 3.14159265f / 180.0f) * (screen_h * 0.5f);
        if (radius < 8.0f) radius = 8.0f;

        ImU32 col = ImGui::ColorConvertFloat4ToU32(ImVec4(s_fov_color[0], s_fov_color[1], s_fov_color[2], s_fov_color[3]));
        dl->AddCircle(ImVec2((float)p.x, (float)p.y), radius, col, 128, s_fov_thick);
    }

    void DrawTab() {
        ImGui::BeginChild("##aim_scroll", ImVec2(0, 0), false);

        ImGui::TextUnformatted("Aimbot");
        ImGui::Separator();
        ImGui::Checkbox("Enable Aimbot", &s_enabled);
        ImGui::BeginDisabled(!s_enabled);

        ImGui::Checkbox("Team Check", &s_team_check);

        ImGui::TextUnformatted("Activation");
        const char* keys[] = { "Always", "Left Click", "Right Click", "Shift", "Alt", "E", "Q" };
        ImGui::SetNextItemWidth(-1);
        ImGui::Combo("##aim_key", &s_aim_key, keys, IM_ARRAYSIZE(keys));

        ImGui::TextUnformatted("FOV (degrees)");
        ImGui::SetNextItemWidth(-1);
        ImGui::SliderFloat("##aim_fov", &s_fov, 5, 360, "%.0f");

        ImGui::TextUnformatted("Max Distance");
        ImGui::SetNextItemWidth(-1);
        ImGui::SliderFloat("##aim_maxd", &s_max_dist, 50.0f, 2000.0f, "%.0f");

        ImGui::Spacing();
        ImGui::TextUnformatted("Smoothing");
        ImGui::Separator();
        ImGui::Checkbox("Enable Smoothing", &s_smooth);
        if (s_smooth) {
            ImGui::SetNextItemWidth(-1);
            ImGui::SliderFloat("##aim_smooth", &s_aim_speed_dps, 10.0f, 10000.0f, "Speed: %.0f");
        }

        ImGui::Spacing();
        ImGui::TextUnformatted("FOV Circle");
        ImGui::Separator();
        ImGui::Checkbox("Draw FOV", &s_draw_fov);
        if (s_draw_fov) {
            ImGui::ColorEdit4("##fov_col", s_fov_color, ImGuiColorEditFlags_AlphaBar);
            ImGui::SliderFloat("##fov_thick", &s_fov_thick, 0.5f, 5.0f, "%.1f");
        }

        ImGui::EndDisabled();
        ImGui::EndChild();
    }

    void SaveConfig(std::unordered_map<std::string, std::string>& m) {}
    void LoadConfig(const std::unordered_map<std::string, std::string>& m) {}
    void ApplyAfterLoad() {}
}